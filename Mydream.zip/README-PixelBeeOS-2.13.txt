PIXELBEEOS 2.13 - LAUNCHPAD REDESIGN
====================================

This release improves the Launchpad based on the supplied desktop recordings.

LAUNCHPAD CHANGES
-----------------
- Reworked the launcher into a centered, responsive glass panel.
- Uses a wider layout on desktop displays and adapts to smaller resolutions.
- App tiles have consistent spacing, icon backplates, hover feedback and centered labels.
- Long app names are shortened cleanly to avoid overlapping neighboring tiles.
- Panel height adapts to the number of app rows, reducing unused empty space.
- Search remains available for apps, files and folders; result rows remain clickable.
- Keyboard Enter/Escape and existing mouse hit targets are preserved.

PRESERVED FROM 2.12
------------------
- Existing PS/2 keyboard and mouse initialization changes.
- Existing freestanding 64-bit division helper used by the kernel link.
- Existing apps, filesystem, desktop, window manager and low-RAM checks.

BUILD
-----
Run: make
Run host-side UI checks: make host-test
Build ISO (requires GRUB rescue tools): make iso

The host test suite passes. The freestanding kernel compiles and links.
Physical hardware testing is still required for real keyboard/mouse compatibility.
Native USB HID controller drivers are not included in this release.
