# PixelBeeOS 3.1 - Internet status

## What now exists
| Layer | File | Notes |
|---|---|---|
| Network card drivers | `netdrv.h` | Intel e1000 family (QEMU / VirtualBox / VMware default) and Realtek RTL8139. Polled, no interrupts. |
| Ethernet, ARP, IPv4, ICMP | `net.h` | ping works both ways (answers pings and ARP too) |
| UDP, **DHCP** client, **DNS** resolver | `net.h` | follows CNAME, handles NXDOMAIN, retries and timeouts |
| **TCP** client | `net.h` | one connection at a time; retransmits lost SYN/request; drops out-of-order data and re-ACKs; honours RST; advertises a real receive window |
| **HTTP/1.1** client | `net.h` | redirects (301/302/303/307/308, up to 4), chunked bodies, Content-Length, 58 KB page limit (flagged as cut) |
| **HTTPS: TLS 1.3** | `crypto.h`, `tls.h`, `nettls.h` | SHA-256, HMAC, HKDF, AES-128-GCM, X25519 written from scratch; cipher TLS_AES_128_GCM_SHA256 only; `https://` works in the terminal (`http`, `get`) and BeeBrowser |
| Terminal commands | `netcmd.h` | `net`, `net up`, `ping HOST`, `dns HOST`, `http URL`, `get URL /diskpath` |
| BeeBrowser | `apps.h`, `netcmd.h` | typing an http:// address (or `www.x.com`) now loads the real page through the HTML renderer |

## Network app (no commands needed)
Open **Network** from the Launchpad, the dock, or click the Wi-Fi glyph in the top-right tray (or the NETWORK tile in Control Center).
- Big status card: Connected / Not connected / No network card / Connecting..., with the card name and IP address.
- **Connect**, **Reconnect**, **Disconnect**, **Test internet** (checks router, name lookup and a real web page) and **Open browser** buttons.
- Details: card, MAC, IP, router, DNS, packet counters. "Connect at startup" switch (on by default: one quick DHCP attempt at boot).
- The tray Wi-Fi glyph is bright when online and dimmed with a slash when offline. Device Manager and Security Center now show the real network state.
- While connecting, the screen shows "Connecting..." and then waits for the router (usually under a second in QEMU, up to ~15 s if nothing answers).

## How to try it (QEMU)
(`make run` now adds `-nic user,model=e1000`.)
`make run` now starts QEMU with `-nic user,model=e1000`. In the terminal:
```
net up                   find the card, get an address by DHCP
ping 10.0.2.2            QEMU's gateway
dns example.com
http http://example.com/
http https://example.com/             (encrypted; identity not verified)
get http://example.com/ /page.html      (saves to the mounted PIXELBEEDAT disk: disk mount 0 1)
```
VirtualBox: Network adapter "Intel PRO/1000 MT Desktop" (NAT). VMware: e1000.

## How it was tested
`make test-network` runs the stack against a simulated internet that builds and checks its own packets
(independent checksum code): gateway, DHCP, DNS, ping responder and a web server. Covered: lost DHCP/SYN/request,
out-of-order TCP segments with server retransmission, a 100 KB page (truncation flagged), chunked body, redirect, 404,
refused port, DNS timeout/NXDOMAIN/CNAME, corrupt checksums ignored, ARP/ping answered. The same test is run again
**through the real e1000 and RTL8139 drivers** using register-level models of both chips (descriptor rings, DMA, the
RTL8139 wrapping receive buffer). The model found two real bugs in my own code during development.
Also: `make host-test` checks every new command and the browser are safe when no network card exists. All pass.

## HTTPS - read this before trusting it
- **Encrypted: yes.** Anyone just listening to the network cannot read or change the page (AES-GCM, X25519 key exchange, server `Finished` verified).
- **Server identity verified: NO.** The certificate chain and CertificateVerify signature are not checked yet. Someone who actively intercepts
  your connection (hostile Wi-Fi, bad router) could pretend to be the site. The terminal and browser say so every time. **Do not type passwords
  or card numbers.** Fixing this needs X.509 parsing, RSA + ECDSA signature checks, SHA-384 and a root-certificate store: the next big step.
- Only **TLS 1.3** servers work (Google, Cloudflare, Wikipedia, GitHub and most big sites do). TLS 1.2-only servers are refused with a clear message.
- Random numbers: uses the CPU's RDRAND when present, otherwise timing jitter and packet arrival times (weaker). Fine for a hobby OS, not for serious secrets.

## How the TLS code was tested
`make test-tls`: 847 checks of the crypto primitives against published RFC/NIST vectors and Python's `cryptography` library on random inputs;
33 handshake/transfer tests against a real **OpenSSL** TLS 1.3 server (bodies from 0 B to 200 KB, tampered bytes detected, TLS 1.2 server refused, repeated
handshakes); and the **whole stack** (TCP + TLS + HTTP) through the simulated internet and the e1000 driver model against OpenSSL. Not yet run against the real internet.

## NOT done / limits (be realistic)
1. **Certificate validation** (see above). 2. TLS 1.2 servers. 3. **Not tested on real hardware / real sites yet**: please try `http https://example.com/`.
4. Cards: no Wi-Fi, no Realtek RTL8168/8169 (most modern PCs), no Intel e1000e/I2xx, no virtio-net, no USB Ethernet.
5. The screen freezes while a request is in progress (up to ~25 s worst case); no background downloads.
6. One TCP connection at a time, no IPv6, no IP fragmentation, no DHCP lease renewal, no gzip, no cookies, no JavaScript.
7. Browser renders HTML as text blocks and links only - no images, CSS or scripts. Many modern sites are empty without JavaScript.
