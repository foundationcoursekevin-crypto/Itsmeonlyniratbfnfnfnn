/* Round-trips pixels through display.h for every format the kernel accepts and decodes them back the way a panel would. */
#include <stdio.h>
#include <string.h>
typedef unsigned char u8; typedef unsigned short u16; typedef unsigned int u32;
static u32 fb_bpp, fb_bytes; static u8 fb_rp, fb_gp, fb_bp, fb_rs, fb_gs, fb_bs;
#include "../display.h"
static int fails;
static void setfmt(u32 bpp, u8 rp, u8 rs, u8 gp, u8 gs, u8 bp, u8 bs) { fb_bpp = bpp; fb_bytes = (bpp + 7) / 8; fb_rp = rp; fb_rs = rs; fb_gp = gp; fb_gs = gs; fb_bp = bp; fb_bs = bs; }
static u32 decode(const u8 *d) {   /* what the display shows: expand each channel back to 8 bits */
    u32 v = fb_bytes == 4 ? *(const u32 *)d : fb_bytes == 3 ? (u32)d[0] | (u32)d[1] << 8 | (u32)d[2] << 16 : *(const u16 *)d;
    u32 r = (v >> fb_rp) & ((1u << fb_rs) - 1), g = (v >> fb_gp) & ((1u << fb_gs) - 1), b = (v >> fb_bp) & ((1u << fb_bs) - 1);
    r <<= 8 - fb_rs; g <<= 8 - fb_gs; b <<= 8 - fb_bs;
    return r << 16 | g << 8 | b;
}
static void run(const char *name, int tol) {
    u32 src[64]; u8 out[64 * 4]; int worst = 0;
    for (int i = 0; i < 64; i++) src[i] = (u32)(i * 4) << 16 | (u32)(255 - i * 4) << 8 | (u32)((i * 37) & 255);
    src[0] = 0x000000; src[1] = 0xFFFFFF; src[2] = 0xFF0000; src[3] = 0x00FF00; src[4] = 0x0000FF;
    memset(out, 0xEE, sizeof out); fb_store(out, src, 64, 0, 0);
    for (int i = 0; i < 64; i++) for (int s = 0; s < 24; s += 8) {
        int a = (src[i] >> s) & 255, b = (decode(out + i * fb_bytes) >> s) & 255, d = a > b ? a - b : b - a; if (d > worst) worst = d; }
    if (fb_bytes == 3 && out[64 * 3] != 0xEE) { printf("FAIL %s: wrote past the end\n", name); fails++; }
    if (fb_bytes == 4 && fb_bs == 8 && ((u32 *)out)[63] >> 24) { printf("FAIL %s: stray alpha byte\n", name); fails++; }
    printf("%-22s worst channel error %3d (limit %d)\n", name, worst, tol); if (worst > tol) { printf("FAIL %s\n", name); fails++; }
}
int main(void) {
    setfmt(32, 16, 8, 8, 8, 0, 8); run("32bpp RGB (0xRRGGBB)", 0);
    setfmt(32, 0, 8, 8, 8, 16, 8); run("32bpp BGR", 0);
    setfmt(24, 16, 8, 8, 8, 0, 8); run("24bpp RGB", 0);
    setfmt(24, 0, 8, 8, 8, 16, 8); run("24bpp BGR", 0);
    setfmt(16, 11, 5, 5, 6, 0, 5); run("16bpp 565 (dithered)", 8);
    setfmt(16, 0, 5, 5, 6, 11, 5); run("16bpp 565 BGR", 8);
    setfmt(15, 10, 5, 5, 5, 0, 5); run("15bpp 555 (dithered)", 8);
    /* pure white must stay pure white and black black even after dithering */
    setfmt(16, 11, 5, 5, 6, 0, 5); u32 w = 0xFFFFFF, k = 0; u8 o[2]; fb_store(o, &w, 1, 3, 3); if (*(u16 *)o != 0xFFFF) { printf("FAIL white\n"); fails++; } fb_store(o, &k, 1, 2, 1); if (*(u16 *)o) { printf("FAIL black\n"); fails++; }
    printf(fails ? "Display test FAILED\n" : "Display test: PASS\n"); return fails != 0;
}
