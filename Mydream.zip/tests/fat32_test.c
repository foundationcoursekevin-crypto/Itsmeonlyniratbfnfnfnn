/* Host test for fat32.h: file-backed block device, then an independent Python checker validates the image. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned char u8; typedef unsigned short u16; typedef unsigned int u32;
#include "../fat32.h"
static FILE *img; static unsigned nread, nwrite; static int fail_after = -1;
static int h_read(void *c, u32 lba, u32 n, void *b) { (void)c; fseek(img, (long)lba * 512, SEEK_SET); nread++; return fread(b, 512, n, img) != n; }
static int h_write(void *c, u32 lba, u32 n, const void *b) { (void)c; if (fail_after == 0) return 1; if (fail_after > 0) fail_after--; fseek(img, (long)lba * 512, SEEK_SET); nwrite++; return fwrite(b, 512, n, img) != n; }
#define CHECK(x) do { if (!(x)) { printf("FAIL line %d: %s\n", __LINE__, #x); exit(1); } } while (0)
static void fill(u8 *b, u32 n, u32 seed) { for (u32 i = 0; i < n; i++) b[i] = (u8)((i * 31 + seed * 17 + (i >> 8)) & 255); }
int main(int argc, char **argv) {
    const char *path = argc > 1 ? argv[1] : "/tmp/fat.img"; u32 total = 131072;     /* 64 MiB disk, MBR partition starts at sector 2048 */
    img = fopen(path, "w+b"); CHECK(img); u8 z[512] = {0}; for (u32 i = 0; i < total; i++) fwrite(z, 512, 1, img);
    BlockDev d = {total, h_read, h_write, 0, 0, "t0"};
    u8 mbr[512] = {0}; mbr[446 + 4] = 0x0C; mbr[446 + 8] = 0x00; mbr[446 + 9] = 0x08; u32 psz = total - 2048; f_w32(mbr + 446 + 12, psz); mbr[510] = 0x55; mbr[511] = 0xAA;
    CHECK(blk_write(&d, 0, 1, mbr) == 0);
    u32 lba, n; u8 ty; CHECK(mbr_part(&d, 0, &lba, &n, &ty) && lba == 2048 && n == psz && ty == 0x0C);
    CHECK(f32_format(&d, lba, n, "PIXELBEEDAT", 0x1234ABCD) == 0);
    static F32 v; CHECK(f32_mount(&v, &d, lba, n) == 0); CHECK(!v.ro && !v.was_dirty);
    f32_set_clock(2026, 11, 21, 12, 30, 10);
    /* plain 8.3 names, long names, mixed case, folders, nested paths */
    CHECK(f32_mkdir(&v, "/DOCS") == 0); CHECK(f32_mkdir(&v, "/docs") == F32_EEXIST);
    CHECK(f32_mkdir(&v, "/My Long Folder Name") == 0);
    CHECK(f32_write_file(&v, "/HELLO.TXT", "hello world", 11) == 0);
    CHECK(f32_write_file(&v, "/DOCS/notes.txt", "lower case name", 15) == 0);
    CHECK(f32_write_file(&v, "/My Long Folder Name/A very long file name here.markdown", "long", 4) == 0);
    CHECK(f32_write_file(&v, "/DOCS/empty.bin", "", 0) == 0);
    static u8 big[300000], back[300000]; fill(big, sizeof big, 7);
    CHECK(f32_write_file(&v, "/big.dat", big, sizeof big) == 0);
    /* many files in one folder forces the directory to grow over several clusters */
    CHECK(f32_mkdir(&v, "/many") == 0);
    for (int i = 0; i < 300; i++) { char nm[64]; snprintf(nm, sizeof nm, "/many/File number %d with long name.txt", i); char dt[16]; int l = snprintf(dt, sizeof dt, "%d", i); CHECK(f32_write_file(&v, nm, dt, (u32)l) == 0); }
    F32Ent e; CHECK(f32_resolve(&v, "/hello.txt", &e) == 0 && e.size == 11); char tmp[64]; CHECK(f32_read(&v, &e, 0, tmp, 64) == 11 && !memcmp(tmp, "hello world", 11));
    CHECK(f32_resolve(&v, "/docs/NOTES.TXT", &e) == 0 && e.size == 15); CHECK(f32_read(&v, &e, 6, tmp, 4) == 4 && !memcmp(tmp, "case", 4));
    CHECK(f32_resolve(&v, "/my long folder name/a very long file name here.markdown", &e) == 0 && !strcmp(e.name, "A very long file name here.markdown"));
    CHECK(f32_resolve(&v, "/big.dat", &e) == 0 && e.size == sizeof big); CHECK(f32_read(&v, &e, 0, back, sizeof back) == (int)sizeof big && !memcmp(big, back, sizeof big));
    CHECK(f32_read(&v, &e, 4093, back, 5000) == 5000 && !memcmp(back, big + 4093, 5000));              /* unaligned read across clusters */
    for (int i = 0; i < 300; i += 17) { char nm[64], dt[16]; snprintf(nm, sizeof nm, "/many/File number %d with long name.txt", i); CHECK(f32_resolve(&v, nm, &e) == 0); int l = snprintf(dt, sizeof dt, "%d", i); CHECK(f32_read(&v, &e, 0, tmp, 64) == l && !memcmp(tmp, dt, (size_t)l)); }
    /* overwrite (bigger then smaller) keeps a single entry and frees old clusters */
    u32 free0 = f32_free_clusters(&v);
    CHECK(f32_write_file(&v, "/big.dat", "tiny", 4) == 0); CHECK(f32_free_clusters(&v) > free0);
    CHECK(f32_resolve(&v, "/big.dat", &e) == 0 && e.size == 4);
    /* errors */
    CHECK(f32_write_file(&v, "/DOCS", "x", 1) == F32_EISDIR); CHECK(f32_write_file(&v, "/bad:name", "x", 1) == F32_ENAME); CHECK(f32_write_file(&v, "/nodir/x.txt", "x", 1) == F32_ENOENT);
    CHECK(f32_remove(&v, "/DOCS") == F32_ENOTEMPTY); CHECK(f32_remove(&v, "/nope") == F32_ENOENT); CHECK(f32_remove(&v, "/") == F32_ENAME);
    /* delete a long-name file and a folder, then reuse the slots */
    CHECK(f32_remove(&v, "/my long folder name/a very long file name here.markdown") == 0); CHECK(f32_remove(&v, "/My Long Folder Name") == 0);
    CHECK(f32_resolve(&v, "/My Long Folder Name", &e) == F32_ENOENT);
    CHECK(f32_remove(&v, "/DOCS/empty.bin") == 0); CHECK(f32_write_file(&v, "/DOCS/again.txt", "again", 5) == 0);
    CHECK(f32_unmount(&v) == 0);
    /* remount: persistence + clean flag */
    CHECK(f32_mount(&v, &d, lba, n) == 0 && !v.was_dirty);
    CHECK(f32_resolve(&v, "/DOCS/again.txt", &e) == 0 && e.size == 5); CHECK(f32_resolve(&v, "/hello.txt", &e) == 0);
    CHECK(f32_write_file(&v, "/crash.txt", "x", 1) == 0);               /* leave the volume mounted (no unmount): simulates power loss */
    CHECK(f32_mount(&v, &d, lba, n) == 0 && v.was_dirty);                /* the dirty flag must be reported on the next mount */
    CHECK(f32_unmount(&v) == 0);
    /* read-only protection: any other label mounts read-only and refuses every write */
    CHECK(f32_format(&d, lba, n, "OTHERDISK", 1) == 0); CHECK(f32_mount(&v, &d, lba, n) == 0 && v.ro);
    CHECK(f32_write_file(&v, "/x.txt", "x", 1) == F32_EROFS); CHECK(f32_mkdir(&v, "/x") == F32_EROFS); CHECK(f32_remove(&v, "/x") == F32_EROFS);
    /* I/O failure injection: a failing write must return an error, not corrupt silently */
    CHECK(f32_format(&d, lba, n, "PIXELBEEDAT", 2) == 0); CHECK(f32_mount(&v, &d, lba, n) == 0);
    fail_after = 3; CHECK(f32_write_file(&v, "/fail.bin", big, 100000) == F32_EIO); fail_after = -1;
    CHECK(f32_resolve(&v, "/fail.bin", &e) == F32_ENOENT);               /* failed write must leave no directory entry */
    /* bounds: formatting outside the disk or too small must be refused */
    CHECK(f32_format(&d, lba, n + 5000, "X", 3) != 0); CHECK(f32_format(&d, 5, 1000, "X", 3) != 0);
    /* final image for the independent checker: a populated, cleanly unmounted volume */
    CHECK(f32_format(&d, lba, n, "PIXELBEEDAT", 0x1234ABCD) == 0); CHECK(f32_mount(&v, &d, lba, n) == 0);
    CHECK(f32_mkdir(&v, "/DOCS") == 0); CHECK(f32_write_file(&v, "/DOCS/notes.txt", "lower case name", 15) == 0);
    CHECK(f32_write_file(&v, "/HELLO.TXT", "hello world", 11) == 0); CHECK(f32_write_file(&v, "/big.dat", big, sizeof big) == 0);
    CHECK(f32_mkdir(&v, "/many") == 0);
    for (int i = 0; i < 120; i++) { char nm[64]; snprintf(nm, sizeof nm, "/many/File number %d with long name.txt", i); CHECK(f32_write_file(&v, nm, nm, (u32)strlen(nm)) == 0); }
    CHECK(f32_write_file(&v, "/many/File number 5 with long name.txt", "replaced", 8) == 0); CHECK(f32_remove(&v, "/many/File number 9 with long name.txt") == 0);
    CHECK(f32_unmount(&v) == 0); fclose(img);
    printf("fat32 host tests: PASS (reads %u, writes %u)\n", nread, nwrite); return 0;
}
