#!/usr/bin/env python3
"""Runs tests/net_test built with -DTLS_BRIDGE=1: a simulated internet whose port 443 relays to a REAL OpenSSL TLS 1.3 server."""
import sys, os, subprocess
sys.argv = [sys.argv[0], '/bin/true'] + sys.argv[1:]; binary = sys.argv[2]
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tls_interop.py')).read().split("srv, port = start(ssl.TLSVersion.TLSv1_3)")[0]
exec(src)
srv, port = start(ssl.TLSVersion.TLSv1_3)
r = subprocess.run([binary], env=dict(os.environ, TLS_PORT=str(port)), capture_output=True, text=True, timeout=300); print(r.stdout.strip()); print(r.stderr.strip()[:2000]); sys.exit(r.returncode)
