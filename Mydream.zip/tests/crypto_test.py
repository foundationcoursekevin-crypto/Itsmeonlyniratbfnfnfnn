#!/usr/bin/env python3
"""Cross-checks crypto.h (through tests/crypto_cli) against published vectors AND Python's hashlib/hmac/cryptography on random inputs."""
import subprocess, os, sys, hmac, hashlib, random
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.kdf.hkdf import HKDFExpand
from cryptography.hazmat.primitives import hashes
cli = sys.argv[1]; random.seed(1234); fails = 0; checks = 0
def run(*a): return subprocess.run([cli, *a], capture_output=True, text=True).stdout.strip()
def check(name, got, want):
    global fails, checks; checks += 1
    if got != want: fails += 1; print('FAIL', name, '\n  got ', got[:80], '\n  want', want[:80])
h = bytes.fromhex
# published vectors
check('sha256 abc', run('sha256', '616263'), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
check('sha256 empty', run('sha256', ''), 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855')
check('hmac rfc4231 #1', run('hmac', '0b' * 20, h('4869205468657265').hex()), 'b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7')
check('x25519 rfc7748 5.2', run('x25519', 'a546e36bf0527c9d3b16154b82465edd62144c0ac1fc5a18506a2244ba449ac4', 'e6db6867583030db3594c1a424b15f7c726624ec26b3353b10a903a6d0ab1c4c'), 'c3da55379de9c6908e94ea4df28d084f32eccf03491c71f754b4075577a28552')
check('x25519 alice pub', run('x25519-base', '77076d0a7318a57d3c16c17251b26645df4c2f87ebc0992ab177fba51db92c2a'), '8520f0098930a754748b7ddcb43ef75a0dbf3a0d26381af4eba4a98eaa9b4e6a')
check('x25519 shared', run('x25519', '77076d0a7318a57d3c16c17251b26645df4c2f87ebc0992ab177fba51db92c2a', 'de9edb7d7b7dc1b4d35b61c2ece435373f8343c85b78674dadfc7e146f882b4f'), '4a5d9d5ba4ce2de1728e3bf480350f25e07e21c947d19e3376f09b3c1e161742')
k = '00112233445566778899aabbccddeeff'
check('gcm nist tc4', run('gcm-seal', 'feffe9928665731c6d6a8f9467308308', 'cafebabefacedbaddecaf888', 'feedfacedeadbeeffeedfacedeadbeefabaddad2',
      'd9313225f88406e5a55909c5aff5269a86a7a9531534f7da2e4c303d8a318a721c3c0c95956809532fcf0e2449a6b525b16aedf5aa0de657ba637b39'),
      '42831ec2217774244b7221b784d0d49ce3aa212f2c02a4e035c17e2329aca12e21d514b25466931c7d8f6a5aac84aa051ba30b396a0aac973d58e0915bc94fbc3221a5db94fae95ae7121a47')
# random cross-checks
for i in range(150):
    n = random.choice([0, 1, 55, 56, 63, 64, 65, 119, 120, 1000, random.randint(0, 5000)]); d = os.urandom(n)
    check(f'sha256 rnd {n}', run('sha256', d.hex() or ''), hashlib.sha256(d).hexdigest())
for i in range(100):
    key = os.urandom(random.choice([1, 16, 32, 64, 65, 100])); d = os.urandom(random.randint(0, 300))
    check('hmac rnd', run('hmac', key.hex(), d.hex()), hmac.new(key, d, hashlib.sha256).hexdigest())
for i in range(60):   # TLS 1.3 HKDF-Expand-Label against a reference built from HKDFExpand
    sec = os.urandom(32); ctx = os.urandom(random.choice([0, 32])); lab = random.choice(['key', 'iv', 'finished', 'c hs traffic', 'derived']); ln = random.choice([12, 16, 32])
    full = b'tls13 ' + lab.encode(); info = ln.to_bytes(2, 'big') + bytes([len(full)]) + full + bytes([len(ctx)]) + ctx
    check('hkdf-label', run('hkdf-label', sec.hex(), lab, ctx.hex(), str(ln)), HKDFExpand(hashes.SHA256(), ln, info).derive(sec).hex())
for i in range(150):
    key = os.urandom(16); iv = os.urandom(12); aad = os.urandom(random.choice([0, 5, 13, 16, 33])); pt = os.urandom(random.choice([0, 1, 15, 16, 17, 31, 100, 1300, random.randint(0, 3000)]))
    want = AESGCM(key).encrypt(iv, pt, aad)
    got = run('gcm-seal', key.hex(), iv.hex(), aad.hex() or '', pt.hex() or '')
    check(f'gcm seal rnd {len(pt)}', got, want.hex())
    check('gcm open rnd', run('gcm-open', key.hex(), iv.hex(), aad.hex() or '', want.hex()) or '', pt.hex())
    bad = bytearray(want); bad[random.randrange(len(bad))] ^= 1 << random.randrange(8)
    check('gcm rejects tampering', run('gcm-open', key.hex(), iv.hex(), aad.hex() or '', bytes(bad).hex()), 'FAIL')
for i in range(40):
    sk = X25519PrivateKey.generate(); pk = X25519PrivateKey.generate().public_key()
    skb = sk.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption()); pkb = pk.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    check('x25519 rnd', run('x25519', skb.hex(), pkb.hex()), sk.exchange(pk).hex())
    check('x25519 base rnd', run('x25519-base', skb.hex()), sk.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex())
print(f'crypto cross-check: {checks - fails}/{checks} passed'); sys.exit(1 if fails else 0)
