/* Software model of an IDE controller (primary channel, one master disk, floating secondary channel) backed by a file.
   Drives ata.h through its real port-I/O path, then runs FAT32 on top of it. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned char u8; typedef unsigned short u16; typedef unsigned int u32;
#define ATA_HOST_EMU 1
static FILE *img; static u32 DISK_SECTORS = 131072;
static struct { int slave; u8 cnt, lo, mid, hi; u8 status; int cmd; u16 buf[256]; int pos; u32 lba; int cmds_wr, cmds_rd; } E;
static u8 inb(u16 p) {
    if (p >= 0x170 && p <= 0x177) return 0xFF;                       /* floating secondary channel */
    if (p == 0x3F6 || p == 0x376) return E.slave ? 0 : E.status;
    if (p < 0x1F0 || p > 0x1F7) return 0xFF;
    if (E.slave) return 0;                                           /* no slave drive */
    switch (p - 0x1F0) { case 4: return E.mid; case 5: return E.hi; case 7: return E.status; default: return 0; }
}
static void outb(u16 p, u8 v) {
    if (p < 0x1F0 || p > 0x1F7) return;
    switch (p - 0x1F0) {
    case 2: E.cnt = v; break; case 3: E.lo = v; break; case 4: E.mid = v; break; case 5: E.hi = v; break;
    case 6: E.slave = (v >> 4) & 1; E.lba = (E.lba & 0x00FFFFFF) | ((u32)(v & 15) << 24); break;
    case 7:
        if (E.slave) return;
        E.lba = (E.lba & 0x0F000000) | ((u32)E.hi << 16) | ((u32)E.mid << 8) | E.lo; E.pos = 0; E.cmd = v;
        if (v == 0xEC) { memset(E.buf, 0, sizeof E.buf); E.buf[60] = (u16)DISK_SECTORS; E.buf[61] = (u16)(DISK_SECTORS >> 16); const char *m = "PIXELBEE EMU DISK"; for (int i = 0; i < 20; i++) { char a = (i * 2 < 17) ? m[i * 2] : ' ', b = (i * 2 + 1 < 17) ? m[i * 2 + 1] : ' '; E.buf[27 + i] = (u16)((u8)a << 8 | (u8)b); } E.status = 0x58; }
        else if (v == 0x20) { if (E.lba >= DISK_SECTORS) { E.status = 0x51; return; } fseek(img, (long)E.lba * 512, SEEK_SET); if (fread(E.buf, 512, 1, img) != 1) E.status = 0x51; else E.status = 0x58; E.cmds_rd++; }
        else if (v == 0x30) { E.status = 0x58; E.cmds_wr++; }
        else if (v == 0xE7) E.status = 0x50;
        else E.status = 0x51;
        break;
    }
}
static u16 ata_inw(u16 p) { (void)p; u16 w = E.buf[E.pos++]; if (E.pos == 256) E.status = 0x50; return w; }
static void ata_outw(u16 p, u16 w) { (void)p; E.buf[E.pos++] = w; if (E.pos == 256) { if (E.lba >= DISK_SECTORS) { E.status = 0x51; return; } fseek(img, (long)E.lba * 512, SEEK_SET); fwrite(E.buf, 512, 1, img); E.status = 0x50; } }
#include "../fat32.h"
#include "../ata.h"
#define CHECK(x) do { if (!(x)) { printf("FAIL line %d: %s\n", __LINE__, #x); exit(1); } } while (0)
int main(void) {
    img = fopen("/tmp/ata.img", "w+b"); CHECK(img); u8 z[512] = {0}; for (u32 i = 0; i < DISK_SECTORS; i++) fwrite(z, 512, 1, img); E.status = 0x50;
    ata_probe(); CHECK(ata_n == 1); CHECK(ata_drv[0].sectors == DISK_SECTORS); CHECK(!strncmp(ata_drv[0].model, "PIXELBEE EMU DISK", 17));
    BlockDev *d = &ata_blk[0];
    u8 mbr[512] = {0}; mbr[446 + 4] = 0x0C; mbr[446 + 9] = 0x08; u32 psz = DISK_SECTORS - 2048; f_w32(mbr + 446 + 12, psz); mbr[510] = 0x55; mbr[511] = 0xAA;
    CHECK(blk_write(d, 0, 1, mbr) == 0); u32 lba, n; u8 ty; CHECK(mbr_part(d, 0, &lba, &n, &ty) && lba == 2048);
    CHECK(f32_format(d, lba, n, F32_DATA_LABEL, 99) == 0);
    static F32 v; CHECK(f32_mount(&v, d, lba, n) == 0 && !v.ro);
    static u8 big[70000], back[70000]; for (u32 i = 0; i < sizeof big; i++) big[i] = (u8)(i * 7 + 3);
    CHECK(f32_write_file(&v, "/ATA test file.bin", big, sizeof big) == 0); CHECK(f32_unmount(&v) == 0);
    CHECK(f32_mount(&v, d, lba, n) == 0 && !v.was_dirty);
    F32Ent e; CHECK(f32_resolve(&v, "/ata test file.bin", &e) == 0 && e.size == sizeof big); CHECK(f32_read(&v, &e, 0, back, sizeof back) == (int)sizeof back && !memcmp(big, back, sizeof big));
    CHECK(blk_read(d, DISK_SECTORS, 1, back) != 0);                    /* out-of-range access is refused before any port I/O */
    CHECK(blk_write(d, DISK_SECTORS - 1, 2, back) != 0);
    f32_unmount(&v); fclose(img);
    printf("ATA emulation + FAT32 over ATA: PASS (%d sector reads, %d sector writes through the driver)\n", E.cmds_rd, E.cmds_wr); return 0;
}
