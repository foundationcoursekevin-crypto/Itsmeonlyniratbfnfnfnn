/* Builds fake RSDP/RSDT/FADT/DSDT tables in a blob and checks acpi.h finds the PM1 ports, the _S5_ sleep type and the reset register. */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef unsigned char u8; typedef unsigned short u16; typedef unsigned int u32;
static u8 mem[0x110000];
#define ACPI_PHYS(a) ((const volatile u8 *)(mem + (a)))
static int log_n; static struct { char k; u16 port; u32 v; } log_[16];
static void outb(u16 p, u8 v) { log_[log_n].k = 'b'; log_[log_n].port = p; log_[log_n++].v = v; }
static void outw(u16 p, u16 v) { log_[log_n].k = 'w'; log_[log_n].port = p; log_[log_n++].v = v; }
static u16 sci_en = 0;
static u16 inw(u16 p) { (void)p; return sci_en; }
#include "../acpi.h"
static void w32(u32 a, u32 v) { memcpy(mem + a, &v, 4); }
static void fixsum(u32 a, u32 n, u32 cs) { mem[a + cs] = 0; u8 s = 0; for (u32 i = 0; i < n; i++) s = (u8)(s + mem[a + i]); mem[a + cs] = (u8)(0 - s); }
static int fails;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static void build(const u8 *s5, int s5len, int with_reset, int root_char, u32 rsdp_at) {
    memset(mem, 0, sizeof mem);
    u32 rsdt = 0x7000, fadt = 0x7100, dsdt = 0x7400;
    memcpy(mem + rsdp_at, "RSD PTR ", 8); mem[rsdp_at + 15] = 0; w32(rsdp_at + 16, rsdt); fixsum(rsdp_at, 20, 8);
    memcpy(mem + rsdt, "RSDT", 4); w32(rsdt + 4, 40); w32(rsdt + 36, fadt); fixsum(rsdt, 40, 9);
    memcpy(mem + fadt, "FACP", 4); w32(fadt + 4, 244); w32(fadt + 40, dsdt); w32(fadt + 48, 0xB2); mem[fadt + 52] = 0xA0;
    w32(fadt + 64, 0x604); w32(fadt + 68, 0);
    if (with_reset) { w32(fadt + 112, 1u << 10); mem[fadt + 116] = 1; w32(fadt + 120, 0xCF9); mem[fadt + 128] = 6; }
    fixsum(fadt, 244, 9);
    memcpy(mem + dsdt, "DSDT", 4); u32 body = 36 + 40; memset(mem + dsdt + 36, 0xA5, 40);
    mem[dsdt + body] = 0x08; if (root_char) mem[dsdt + body] = 0x08, mem[dsdt + body + 1] = '\\', memcpy(mem + dsdt + body + 2, "_S5_", 4), memcpy(mem + dsdt + body + 6, s5, s5len);
    else { memcpy(mem + dsdt + body + 1, "_S5_", 4); memcpy(mem + dsdt + body + 5, s5, s5len); }
    w32(dsdt + 4, 36 + 40 + 40); fixsum(dsdt, 116, 9);
}
int main(void) {
    static const u8 pkgA[] = {0x12, 0x06, 0x04, 0x0A, 0x05, 0x0A, 0x05, 0x00, 0x00};   /* typical: Package {5,5,0,0} */
    static const u8 pkgB[] = {0x12, 0x06, 0x04, 0x00, 0x01, 0x00, 0x00};               /* ZeroOp/OneOp encoding: {0,1} */
    static const u8 pkgC[] = {0x12, 0x0B, 0x04, 0x0A, 0x07, 0x0A, 0x03, 0x0A, 0, 0x0A, 0};
    build(pkgA, sizeof pkgA, 1, 1, 0xE0010);
    u32 r = acpi_find_rsdp(); CHECK(r == 0xE0010);
    CHECK(acpi_init_tables(r)); CHECK(acpi_pm1a == 0x604 && acpi_s5_ok && acpi_slp_a == 5 && acpi_slp_b == 5);
    CHECK(acpi_reset_space == 1 && acpi_reset_addr == 0xCF9 && acpi_reset_val == 6);
    log_n = 0; sci_en = 0; acpi_shutdown();                         /* SCI_EN clear: must enable ACPI first, then sleep */
    CHECK(log_n >= 2 && log_[0].k == 'b' && log_[0].port == 0xB2 && log_[0].v == 0xA0);
    CHECK(log_[log_n - 1].k == 'w' && log_[log_n - 1].port == 0x604 && log_[log_n - 1].v == ((5u << 10) | (1u << 13)));
    log_n = 0; sci_en = 1; acpi_shutdown(); CHECK(log_n == 1 && log_[0].port == 0x604);
    log_n = 0; acpi_reboot(); CHECK(log_n == 1 && log_[0].port == 0xCF9 && log_[0].v == 6);
    build(pkgB, sizeof pkgB, 0, 0, 0xF1230);
    r = acpi_find_rsdp(); CHECK(r == 0xF1230); CHECK(acpi_init_tables(r) && acpi_s5_ok && acpi_slp_a == 0 && acpi_slp_b == 1 && acpi_reset_space == -1);
    log_n = 0; acpi_reboot(); CHECK(log_n == 0);
    build(pkgC, sizeof pkgC, 0, 1, 0xE0000);
    CHECK(acpi_init_tables(acpi_find_rsdp()) && acpi_slp_a == 7 && acpi_slp_b == 3);
    /* EBDA location */
    build(pkgA, sizeof pkgA, 0, 1, 0x9F800); mem[0x40E] = 0x80; mem[0x40F] = 0x9F;
    CHECK(acpi_find_rsdp() == 0x9F800);
    /* corruption must be rejected, never crash */
    build(pkgA, sizeof pkgA, 0, 1, 0xE0010); mem[0x7000 + 20] ^= 1; CHECK(!acpi_init_tables(acpi_find_rsdp()));
    build(pkgA, sizeof pkgA, 0, 1, 0xE0010); mem[0xE0010 + 3] = 'X'; CHECK(acpi_find_rsdp() == 0);
    memset(mem, 0xFF, sizeof mem); CHECK(acpi_find_rsdp() == 0 && !acpi_init_tables(0));
    log_n = 0; acpi_shutdown(); CHECK(log_n == 0);                       /* no tables: must not touch any port */
    printf(fails ? "ACPI test FAILED (%d)\n" : "ACPI test: PASS\n", fails); return fails != 0;
}
