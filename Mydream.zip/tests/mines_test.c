/* Minesweeper rules: first click is never a mine, flood fill opens zeros, clearing every safe cell wins, a mine loses, flags block reveals. */
#define HOSTTEST 1
#include "../kernel.c"
#include <stdio.h>
static int fails;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main(void) {
    W = 1366; H = 768; PITCH = W * 4; kernel_init();
    for (int g = 0; g < 500; g++) {                                   /* many games, different first cells and timestamps */
        cur_ms = 1000 + (u32)g * 7919; ms_reset(); int first = (g * 13) % 81; ms_reveal(first);
        int mines = 0; for (int i = 0; i < 81; i++) mines += ms_mine[i];
        CHECK(mines == MS_MINES); CHECK(!ms_mine[first]); CHECK(ms_state == 0 || ms_state == 2); CHECK(ms_open[first]);
        for (int i = 0; i < 81; i++) if (ms_open[i] && !ms_mine[i] && ms_adj(i) == 0) {          /* an open zero must have all neighbours open */
            int x = i % 9, y = i / 9; for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) { int xx = x + dx, yy = y + dy; if (xx >= 0 && yy >= 0 && xx < 9 && yy < 9) CHECK(ms_open[yy * 9 + xx]); } }
        for (int i = 0; i < 81; i++) if (!ms_mine[i]) ms_reveal(i);
        CHECK(ms_state == 2);
    }
    ms_reset(); cur_ms = 5000; ms_reveal(0); int m = -1; for (int i = 0; i < 81; i++) if (ms_mine[i]) { m = i; break; }
    ms_toggle_flag(m); CHECK(ms_flag[m] && ms_left == MS_MINES - 1); ms_reveal(m); CHECK(ms_state == 0 && !ms_open[m]);   /* flagged: protected */
    ms_toggle_flag(m); ms_reveal(m); CHECK(ms_state == 1);
    app_open_mines(); compose(2000); CHECK(app_on == 16);
    printf(fails ? "Minesweeper test FAILED\n" : "Minesweeper test: PASS\n"); return fails != 0;
}
