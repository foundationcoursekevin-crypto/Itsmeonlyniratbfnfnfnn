/* tiny CLI around crypto.h so Python can cross-check it against hashlib / hmac / cryptography on random inputs */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned char u8; typedef unsigned short u16; typedef unsigned int u32;
#include "../crypto.h"
static int unhex(const char *s, u8 *o) { int n = (int)strlen(s) / 2; for (int i = 0; i < n; i++) { unsigned v; sscanf(s + 2 * i, "%2x", &v); o[i] = (u8)v; } return n; }
static void phex(const u8 *d, int n) { for (int i = 0; i < n; i++) printf("%02x", d[i]); printf("\n"); }
int main(int argc, char **argv) {
    static u8 a[100000], b[100000], c[100000], d[100000], o[100000]; if (argc < 2) return 2; const char *m = argv[1];
    if (!strcmp(m, "sha256")) { int n = unhex(argv[2], a); sha256(a, (u32)n, o); phex(o, 32); }
    else if (!strcmp(m, "hmac")) { int k = unhex(argv[2], a), n = unhex(argv[3], b); hmac_sha256(a, (u32)k, b, (u32)n, o); phex(o, 32); }
    else if (!strcmp(m, "hkdf-label")) { int s = unhex(argv[2], a), cl = unhex(argv[4], b); hkdf_label(a, argv[3], b, (u32)cl, (u32)atoi(argv[5]), o); (void)s; phex(o, atoi(argv[5])); }
    else if (!strcmp(m, "gcm-seal")) { unhex(argv[2], a); int il = unhex(argv[3], b); int al = unhex(argv[4], c); int pl = unhex(argv[5], d); (void)il; Gcm g; gcm_key(&g, a); gcm_seal(&g, b, c, (u32)al, d, (u32)pl, o); phex(o, pl + 16); }
    else if (!strcmp(m, "gcm-open")) { unhex(argv[2], a); unhex(argv[3], b); int al = unhex(argv[4], c); int cl = unhex(argv[5], d); Gcm g; gcm_key(&g, a); int r = gcm_open(&g, b, c, (u32)al, d, (u32)(cl - 16), o); if (r) printf("FAIL\n"); else phex(o, cl - 16); }
    else if (!strcmp(m, "x25519")) { unhex(argv[2], a); unhex(argv[3], b); x25519(o, a, b); phex(o, 32); }
    else if (!strcmp(m, "x25519-base")) { unhex(argv[2], a); x25519_base(o, a); phex(o, 32); }
    else return 2; return 0;
}
