#!/usr/bin/env python3
"""Independent FAT32 checker (shares no code with fat32.h). Usage: verify_fat32.py image [partition-index]
Checks: BPB sanity, FSInfo, both FAT copies identical, every directory/LFN entry, checksums, '.'/'..' entries,
chain lengths vs file sizes, cross-linked clusters, lost clusters, free-count, clean-shutdown bit."""
import struct, sys
def main(path, pidx=0):
    d = open(path, 'rb').read(); errs = []
    def err(m): errs.append(m)
    e = 446 + pidx * 16; ptype = d[e + 4]; base, psz = struct.unpack_from('<II', d, e + 8)
    if ptype not in (0x0B, 0x0C): err(f'partition type {ptype:#x} is not FAT32')
    b = d[base * 512: base * 512 + 512]
    if b[510:512] != b'\x55\xaa': err('missing boot signature')
    bps, spc, rsvd, nf = struct.unpack_from('<HBHB', b, 11); fsz = struct.unpack_from('<I', b, 36)[0]; tot = struct.unpack_from('<I', b, 32)[0]
    root = struct.unpack_from('<I', b, 44)[0]; fsinfo, backup = struct.unpack_from('<HH', b, 48)
    if bps != 512 or spc & (spc - 1) or not spc: err('bad BPB geometry')
    if b[82:90] != b'FAT32   ': err('missing FAT32 type string')
    if b[510:512] != d[(base + backup) * 512 + 510:(base + backup) * 512 + 512] or d[(base + backup) * 512:(base + backup) * 512 + 512] != b: err('backup boot sector differs')
    ncl = (tot - rsvd - nf * fsz) // spc
    if ncl < 65525: err(f'only {ncl} clusters: not a valid FAT32')
    f0 = (base + rsvd) * 512; fats = [d[f0 + k * fsz * 512: f0 + (k + 1) * fsz * 512] for k in range(nf)]
    if nf == 2 and fats[0] != fats[1]: err('FAT copies differ')
    fat = lambda c: struct.unpack_from('<I', fats[0], c * 4)[0] & 0x0FFFFFFF
    if fat(0) & 0xFF != 0xF8: err('FAT[0] media byte wrong')
    if not (struct.unpack_from('<I', fats[0], 4)[0] & 0x08000000): err('clean-shutdown bit not set')
    fi = d[(base + fsinfo) * 512:(base + fsinfo) * 512 + 512]
    if struct.unpack_from('<I', fi, 0)[0] != 0x41615252 or struct.unpack_from('<I', fi, 484)[0] != 0x61417272 or struct.unpack_from('<I', fi, 508)[0] != 0xAA550000: err('FSInfo signatures bad')
    data0 = (base + rsvd + nf * fsz) * 512; csz = spc * 512
    def chain(c):
        out = []; seen = set()
        while 2 <= c < ncl + 2:
            if c in seen: err(f'loop in chain at {c}'); break
            seen.add(c); out.append(c); n = fat(c)
            if n >= 0x0FFFFFF8: return out
            c = n
        err(f'chain does not end properly (last {c:#x})'); return out
    owner = {}; files = {}
    def claim(c, who):
        for x in c:
            if x in owner: err(f'cluster {x} claimed by {owner[x]} and {who}')
            owner[x] = who
    def cdata(cl): return b''.join(d[data0 + (x - 2) * csz: data0 + (x - 1) * csz] for x in cl)
    def ck(s):
        r = 0
        for ch in s: r = (((r & 1) << 7) + (r >> 1) + ch) & 0xFF
        return r
    def walk(cl, p, parent):
        ch = chain(cl); claim(ch, p or '/'); raw = cdata(ch); i = 0; lfn = None; seen_dot = []
        while i < len(raw):
            ent = raw[i:i + 32]; i += 32
            if ent[0] == 0: 
                if any(raw[i:]): err(f'{p}: non-zero data after end marker')
                break
            if ent[0] == 0xE5: lfn = None; continue
            attr = ent[11]
            if attr == 0x0F:
                o = ent[0]
                if o & 0x40: lfn = {'n': o & 0x3F, 'ck': ent[13], 'parts': {}, 'next': (o & 0x3F)}
                elif lfn is None or ent[13] != lfn['ck'] or (o & 0x3F) != lfn['next']: err(f'{p}: broken LFN sequence'); lfn = None; continue
                if lfn is None: continue
                chars = ent[1:11] + ent[14:26] + ent[28:32]; u = chars.decode('utf-16le'); lfn['parts'][o & 0x3F] = u.split('\x00')[0] if '\x00' in u else u.replace('\uffff', '')
                lfn['next'] = (o & 0x3F) - 1; continue
            name83 = ent[:8].decode('latin1').rstrip() + ('.' + ent[8:11].decode('latin1').rstrip() if ent[8:11].strip() else '')
            name = name83
            if lfn:
                if lfn['next'] != 0: err(f'{p}: incomplete LFN before {name83}')
                if lfn['ck'] != ck(ent[:11]): err(f'{p}: LFN checksum mismatch for {name83}')
                name = ''.join(lfn['parts'][k] for k in sorted(lfn['parts']))
            lfn = None; cl_ = (struct.unpack_from('<H', ent, 20)[0] << 16) | struct.unpack_from('<H', ent, 26)[0]; size = struct.unpack_from('<I', ent, 28)[0]
            if name83 in ('.', '..'):
                seen_dot.append(name83)
                if name83 == '.' and cl_ != cl: err(f'{p}: "." points to {cl_} not {cl}')
                if name83 == '..' and cl_ != parent: err(f'{p}: ".." points to {cl_} not {parent}')
                continue
            full = (p.rstrip('/') + '/' + name)
            if attr & 0x10:
                if size: err(f'{full}: directory with size {size}')
                walk(cl_, full, 0 if cl == root else cl)
            else:
                c = chain(cl_) if cl_ else []
                if (size + csz - 1) // csz != len(c): err(f'{full}: size {size} needs {(size + csz - 1) // csz} clusters but chain has {len(c)}')
                claim(c, full); files[full] = cdata(c)[:size]
        if cl != root and seen_dot != ['.', '..']: err(f'{p}: missing . / .. entries')
    walk(root, '/', 0)
    for c in range(2, ncl + 2):
        if fat(c) and c not in owner: err(f'lost cluster {c} (allocated but unreachable)'); break
    free = sum(1 for c in range(2, ncl + 2) if fat(c) == 0); fc = struct.unpack_from('<I', fi, 488)[0]
    if fc not in (0xFFFFFFFF, free): err(f'FSInfo free count {fc} != real {free}')
    return errs, files
if __name__ == '__main__':
    structure_only = '--structure' in sys.argv; args = [a for a in sys.argv[1:] if not a.startswith('--')]
    errs, files = main(args[0], int(args[1]) if len(args) > 1 else 0)
    if structure_only: print('files found:', len(files)); print('VERIFY (structure):', 'PASS' if not errs else 'FAIL'); [print('  -', e) for e in errs[:15]]; sys.exit(1 if errs else 0)
    for k in sorted(files)[:6]: print(' ', k, len(files[k]), 'bytes')
    print('files found:', len(files))
    exp = {'/HELLO.TXT': b'hello world', '/DOCS/notes.txt': b'lower case name'}
    for k, v in exp.items():
        if files.get(k) != v: errs.append(f'content mismatch {k}: {files.get(k)!r}')
    big = bytes((i * 31 + 7 * 17 + (i >> 8)) & 255 for i in range(300000))
    if files.get('/big.dat') != big: errs.append('big.dat content mismatch')
    for i in range(120):
        k = f'/many/File number {i} with long name.txt'
        if i == 9:
            if k in files: errs.append('deleted file still present')
        elif i == 5:
            if files.get(k) != b'replaced': errs.append('overwritten file wrong')
        elif files.get(k) != k.encode(): errs.append(f'content mismatch {k}')
    print('VERIFY:', 'PASS' if not errs else 'FAIL'); [print('  -', e) for e in errs[:15]]; sys.exit(1 if errs else 0)
