#!/usr/bin/env python3
"""Interop test: tls.h/crypto.h (C client, tests/tls_client) against a real OpenSSL TLS 1.3 server (Python ssl).
The server returns deterministic bodies, so the client's SHA-256 of the whole HTTP response can be checked exactly."""
import ssl, socket, threading, subprocess, sys, hashlib, os, random, tempfile, time
client = sys.argv[1]; d = tempfile.mkdtemp()
subprocess.run(['openssl', 'req', '-x509', '-newkey', 'ec', '-pkeyopt', 'ec_paramgen_curve:prime256v1', '-nodes', '-keyout', d + '/k.pem', '-out', d + '/c.pem', '-days', '2', '-subj', '/CN=pixelbee.test'], check=True, capture_output=True)
def make_ctx(maxv):
    c = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); c.load_cert_chain(d + '/c.pem', d + '/k.pem'); c.minimum_version = ssl.TLSVersion.TLSv1_2; c.maximum_version = maxv; return c
def body_for(n): return bytes((i * 7 + 3) % 251 for i in range(n))
def response(path):
    if path.startswith('/n/'): b = body_for(int(path[3:])); return b'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: %d\r\nConnection: close\r\n\r\n' % len(b) + b
    return b'HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n'
def serve(ctx, srv):
    while True:
        try: s, _ = srv.accept()
        except OSError: return
        try:
            t = ctx.wrap_socket(s, server_side=True); req = b''
            while b'\r\n\r\n' not in req: 
                x = t.recv(4096)
                if not x: break
                req += x
            path = req.split(b' ')[1].decode() if b' ' in req else '/'; out = response(path); i = 0
            while i < len(out): k = random.choice([1, 7, 500, 1400, 4000, 16384, 30000]); t.sendall(out[i:i + k]); i += k
            t.shutdown(socket.SHUT_RDWR) if False else t.unwrap()
        except Exception as e: pass
        finally:
            try: s.close()
            except Exception: pass
def start(maxv):
    srv = socket.socket(); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); srv.bind(('127.0.0.1', 0)); srv.listen(8)
    threading.Thread(target=serve, args=(make_ctx(maxv), srv), daemon=True).start(); return srv, srv.getsockname()[1]
def run(port, path, *extra): return subprocess.run([client, str(port), 'pixelbee.test', path, *map(str, extra)], capture_output=True, text=True, timeout=60).stdout.strip()
srv, port = start(ssl.TLSVersion.TLSv1_3); fails = 0; n = 0
def expect(name, got, ok):
    global fails, n; n += 1
    if not ok: fails += 1; print('FAIL', name, '->', got[:200])
for size in [0, 1, 15, 16, 17, 1000, 1500, 16383, 16384, 16385, 50000, 200000]:
    out = run(port, f'/n/{size}'); want = response(f'/n/{size}'); h = hashlib.sha256(want).hexdigest()
    expect(f'body {size}', out, out.startswith(f'RESULT ok {len(want)} {h}'))
expect('404', run(port, '/missing'), run(port, '/missing').startswith('RESULT ok'))
for off in [10, 120, 400, 2000]:                       # flip one bit somewhere in the server's byte stream: must be detected
    out = run(port, '/n/3000', off); expect(f'tamper@{off}', out, out.startswith('RESULT handshake-failed') or out.startswith('RESULT read-error'))
srv12, p12 = start(ssl.TLSVersion.TLSv1_2)             # a TLS 1.2-only server must be refused cleanly, not mis-parsed
out = run(p12, '/n/10'); expect('tls1.2-only server refused', out, out.startswith('RESULT handshake-failed') and ('TLS 1.3' in out or 'alert' in out))
for i in range(15):                                    # repeated handshakes (fresh keys each time)
    out = run(port, '/n/777'); expect(f'repeat {i}', out, out.startswith('RESULT ok'))
print(f'TLS 1.3 interop vs OpenSSL: {n - fails}/{n} passed'); sys.exit(1 if fails else 0)
