/* Tests net.h against a simulated internet: gateway + DHCP + DNS server, a ping responder and a web server, with packet
   loss, out-of-order delivery, corrupt packets, redirects, chunked bodies and refused ports. The simulated peer builds and
   verifies packets with its OWN code (not net.h), so a bug in checksums, header layout or the TCP state machine shows up. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <poll.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
typedef unsigned char u8; typedef unsigned short u16; typedef unsigned int u32;
static u32 fake_ms = 1000;
#ifdef NIC_MODEL
static void model_service(void); static void peer_tick(void);
static u32 now_ms(void) { fake_ms++; peer_tick(); model_service(); return fake_ms; }
#else
static u32 now_ms(void) { return fake_ms; }
#endif
#ifdef TLS_BRIDGE
#define NET_HAVE_TLS 1
#include "../crypto.h"
#include "../tls.h"
#endif
#include "../net.h"
#ifdef TLS_BRIDGE
#include "../nettls.h"
#endif

/* ---- independent helpers for the peer ---- */
static unsigned long long ck_acc(const u8 *p, int n, unsigned long long s) { for (int i = 0; i < n; i++) s += (i & 1) ? p[i] : (unsigned long long)p[i] << 8; return s; }
static u16 ck_fin(unsigned long long s) { while (s >> 16) s = (s & 0xFFFF) + (s >> 16); return (u16)(~s & 0xFFFF); }
static u16 ck_l4(const u8 *src, const u8 *dst, int proto, const u8 *seg, int n) { u8 ph[12]; memcpy(ph, src, 4); memcpy(ph + 4, dst, 4); ph[8] = 0; ph[9] = (u8)proto; ph[10] = (u8)(n >> 8); ph[11] = (u8)n; return ck_fin(ck_acc(seg, n, ck_acc(ph, 12, 0))); }
static const u8 GW_MAC[6] = {2, 0, 0, 0, 0, 1}, GW_IP[4] = {192, 168, 1, 1}, CL_IP[4] = {192, 168, 1, 50}, WEB_IP[4] = {93, 184, 216, 34}, PING_IP[4] = {8, 8, 8, 8};
static u8 q[64][1600]; static int ql[64], qh, qt; static int peer_bad, drop_syn = 1, drop_req = 1, drop_discover = 1, swap_order = 1;
static void enq(const u8 *f, int n) { memcpy(q[qt], f, (size_t)n); ql[qt] = n; qt = (qt + 1) & 63; }
static u16 pid;
static void ip_out(const u8 *dmac, const u8 *src, const u8 *dst, int proto, const u8 *pl, int n, int corrupt_ip) {
    u8 f[1600]; memcpy(f, dmac, 6); memcpy(f + 6, GW_MAC, 6); f[12] = 8; f[13] = 0; u8 *ip = f + 14; ip[0] = 0x45; ip[1] = 0; ip[2] = (u8)((20 + n) >> 8); ip[3] = (u8)(20 + n); ip[4] = (u8)(pid >> 8); ip[5] = (u8)pid++; ip[6] = 0; ip[7] = 0; ip[8] = 60; ip[9] = (u8)proto; ip[10] = ip[11] = 0;
    memcpy(ip + 12, src, 4); memcpy(ip + 16, dst, 4); u16 c = ck_fin(ck_acc(ip, 20, 0)); if (corrupt_ip) c ^= 0x1111; ip[10] = (u8)(c >> 8); ip[11] = (u8)c; memcpy(ip + 20, pl, (size_t)n); enq(f, 34 + n);
}
static u8 cl_mac[6];
static void udp_out(const u8 *src, int sp, int dp, const u8 *d, int n, int to_bcast) {
    u8 u[1500]; u[0] = (u8)(sp >> 8); u[1] = (u8)sp; u[2] = (u8)(dp >> 8); u[3] = (u8)dp; u[4] = (u8)((8 + n) >> 8); u[5] = (u8)(8 + n); u[6] = u[7] = 0; memcpy(u + 8, d, (size_t)n);
    static const u8 bc[4] = {255, 255, 255, 255}; const u8 *dst = to_bcast ? bc : CL_IP; u16 c = ck_l4(src, dst, 17, u, 8 + n); u[6] = (u8)(c >> 8); u[7] = (u8)c;
    static const u8 bm[6] = {255, 255, 255, 255, 255, 255}; ip_out(to_bcast ? bm : cl_mac, src, dst, 17, u, 8 + n, 0);
}
/* ---- DHCP / DNS servers ---- */
static void srv_dhcp(const u8 *d, int n) {
    if (n < 241 || d[0] != 1) return; int type = 0; for (int i = 240; i < n && d[i] != 255;) { if (!d[i]) { i++; continue; } if (d[i] == 53) type = d[i + 2]; i += 2 + d[i + 1]; }
    if (type == 1 && drop_discover) { drop_discover = 0; return; }
    u8 r[300]; memset(r, 0, sizeof r); r[0] = 2; r[1] = 1; r[2] = 6; memcpy(r + 4, d + 4, 4); memcpy(r + 16, CL_IP, 4); memcpy(r + 28, d + 28, 6); r[236] = 0x63; r[237] = 0x82; r[238] = 0x53; r[239] = 0x63;
    int i = 240; r[i++] = 53; r[i++] = 1; r[i++] = (u8)(type == 1 ? 2 : 5); r[i++] = 54; r[i++] = 4; memcpy(r + i, GW_IP, 4); i += 4;
    r[i++] = 1; r[i++] = 4; r[i++] = 255; r[i++] = 255; r[i++] = 255; r[i++] = 0; r[i++] = 3; r[i++] = 4; memcpy(r + i, GW_IP, 4); i += 4; r[i++] = 6; r[i++] = 4; memcpy(r + i, GW_IP, 4); i += 4;
    r[i++] = 51; r[i++] = 4; r[i++] = 0; r[i++] = 0; r[i++] = 0x0E; r[i++] = 0x10; r[i++] = 255; if (type == 1 || type == 3) udp_out(GW_IP, 67, 68, r, 300, 1);
}
static void srv_dns(const u8 *d, int n, int sport) {
    char name[100]; int p = 12, k = 0; while (p < n && d[p]) { int l = d[p++]; if (k) name[k++] = '.'; for (int i = 0; i < l; i++) name[k++] = (char)d[p++]; } name[k] = 0; p++;
    u8 r[512]; memset(r, 0, sizeof r); memcpy(r, d, 2); r[2] = 0x81; r[3] = 0x80; r[5] = 1; int qlen = p + 4 - 12; memcpy(r + 12, d + 12, (size_t)qlen); int o = 12 + qlen;
    if (!strcmp(name, "silent.test")) return;
    if (!strcmp(name, "nx.test")) { r[3] = 0x83; udp_out(GW_IP, 53, sport, r, o, 0); return; }
    int an = 1; if (!strcmp(name, "cname.test")) { r[7] = 2; r[o++] = 0xC0; r[o++] = 12; r[o++] = 0; r[o++] = 5; r[o++] = 0; r[o++] = 1; o += 4; r[o++] = 0; r[o++] = 2; r[o++] = 0xC0; r[o++] = 12; an = 2; } else r[7] = 1;
    r[o++] = 0xC0; r[o++] = 12; r[o++] = 0; r[o++] = 1; r[o++] = 0; r[o++] = 1; o += 4; r[o++] = 0; r[o++] = 4; memcpy(r + o, strcmp(name, "ping.test") ? WEB_IP : PING_IP, 4); o += 4; (void)an; udp_out(GW_IP, 53, sport, r, o, 0);
}
/* ---- web server (TCP) ---- */
static struct { int st; u16 cport; u16 sport; u32 c_next, s_iss, acked_off, sent_off; u8 resp[420000]; int rlen; u32 last_send; int fin_sent, eof, tls; } T; static int syn_seen, req_seen;
static void tcp_out(u32 seq, u32 ack, int fl, const u8 *d, int n, int corrupt) {
    u8 s[1500]; memset(s, 0, sizeof s); s[0] = (u8)(T.sport >> 8); s[1] = (u8)T.sport; s[2] = (u8)(T.cport >> 8); s[3] = (u8)T.cport; s[4] = (u8)(seq >> 24); s[5] = (u8)(seq >> 16); s[6] = (u8)(seq >> 8); s[7] = (u8)seq;
    s[8] = (u8)(ack >> 24); s[9] = (u8)(ack >> 16); s[10] = (u8)(ack >> 8); s[11] = (u8)ack; s[12] = 0x50; s[13] = (u8)fl; s[14] = 0xFF; s[15] = 0xFF; if (n) memcpy(s + 20, d, (size_t)n);
    u16 c = ck_l4(WEB_IP, CL_IP, 6, s, 20 + n); if (corrupt) c ^= 0x00FF; s[16] = (u8)(c >> 8); s[17] = (u8)c; ip_out(GW_MAC, WEB_IP, CL_IP, 6, s, 20 + n, 0);
}
static void send_window(void) {
    int sent = 0; while (T.sent_off < (u32)T.rlen && sent < 4) { int n = T.rlen - (int)T.sent_off; if (n > 1400) n = 1400; int last = (T.sent_off + (u32)n == (u32)T.rlen) && T.eof;
        tcp_out(T.s_iss + 1 + T.sent_off, T.c_next, 0x18 | (last ? 1 : 0), T.resp + T.sent_off, n, 0); if (last) T.fin_sent = 1; T.sent_off += (u32)n; sent++; }
    if (T.eof && T.sent_off == (u32)T.rlen && !T.fin_sent) { tcp_out(T.s_iss + 1 + T.sent_off, T.c_next, 0x11, 0, 0, 0); T.fin_sent = 1; }
    T.last_send = fake_ms;
}
static void build_resp(const char *path) {
    char body[110000]; int bl = 0; const char *hdr = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n"; char h[600]; int chunked = 0;
    if (!strcmp(path, "/")) { for (int i = 0; i < 5000; i++) body[bl++] = (char)('a' + i % 26); sprintf(h, "%sContent-Length: %d\r\nConnection: close\r\n\r\n", hdr, bl); }
    else if (!strcmp(path, "/chunked")) { chunked = 1; sprintf(h, "%sTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n", hdr); }
    else if (!strcmp(path, "/redir")) { sprintf(h, "HTTP/1.1 301 Moved Permanently\r\nLocation: /final\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"); }
    else if (!strcmp(path, "/final")) { bl = sprintf(body, "<html><body>final page</body></html>"); sprintf(h, "%sContent-Length: %d\r\nConnection: close\r\n\r\n", hdr, bl); }
    else if (!strcmp(path, "/big")) { for (int i = 0; i < 100000; i++) body[bl++] = (char)('A' + i % 26); sprintf(h, "%sConnection: close\r\n\r\n", hdr); }
    else { bl = sprintf(body, "nope"); sprintf(h, "HTTP/1.1 404 Not Found\r\nContent-Length: %d\r\nConnection: close\r\n\r\n", bl); }
    int hl = (int)strlen(h); memcpy(T.resp, h, (size_t)hl); T.rlen = hl;
    if (chunked) { const char *a = "Wiki", *b = "pedia in\r\n\r\nchunks."; T.rlen += sprintf((char *)T.resp + T.rlen, "%x\r\n%s\r\n%x\r\n%s\r\n0\r\n\r\n", (unsigned)strlen(a), a, (unsigned)strlen(b), b); }
    else { memcpy(T.resp + T.rlen, body, (size_t)bl); T.rlen += bl; }
    T.sent_off = T.acked_off = 0; T.fin_sent = 0; T.eof = 1; T.tls = 0;
}

/* ---- port 443: relay the TCP byte stream to a REAL TLS server on localhost (tests net.h's streaming TCP + nettls.h + tls.h end to end) ---- */
static int tsock = -1, tls_port; static long tls_flip_at = -1, tls_from_srv;
static void tls_pump(int ms) {
    if (tsock < 0 || T.eof) return;
    for (;;) { struct pollfd p = {tsock, POLLIN, 0}; if (poll(&p, 1, ms) <= 0) break; static u8 b[16384]; int k = (int)recv(tsock, b, sizeof b, 0);
        if (k <= 0) { T.eof = 1; break; } if (tls_flip_at >= tls_from_srv && tls_flip_at < tls_from_srv + k) b[tls_flip_at - tls_from_srv] ^= 1; tls_from_srv += k;
        if ((size_t)(T.rlen + k) <= sizeof T.resp) { memcpy(T.resp + T.rlen, b, (size_t)k); T.rlen += k; } ms = 20; }
}
static void srv_tls_tcp(const u8 *s, int n) {
    u32 seq = (u32)s[4] << 24 | (u32)s[5] << 16 | (u32)s[6] << 8 | s[7], ack = (u32)s[8] << 24 | (u32)s[9] << 16 | (u32)s[10] << 8 | s[11]; int fl = s[13], off = (s[12] >> 4) * 4, plen = n - off;
    T.cport = (u16)(s[0] << 8 | s[1]); T.sport = 443;
    if ((fl & 2) && !(fl & 0x10)) {
        if (tsock >= 0) close(tsock); tsock = socket(AF_INET, SOCK_STREAM, 0); struct sockaddr_in a = {0}; a.sin_family = AF_INET; a.sin_port = htons((u16)tls_port); inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
        if (connect(tsock, (struct sockaddr *)&a, sizeof a)) { printf("bridge: cannot reach the TLS server (port %d, errno %d)\n", tls_port, errno); exit(1); }
        T.st = 1; T.tls = 1; T.eof = 0; T.fin_sent = 0; T.c_next = seq + 1; T.s_iss = 0x2000; T.rlen = 0; T.sent_off = T.acked_off = 0; tls_from_srv = 0; tcp_out(T.s_iss, T.c_next, 0x12, 0, 0, 0); return;
    }
    if (!T.st) return;
    if (plen > 0) {
        if (seq == T.c_next) { if (send(tsock, s + off, (size_t)plen, 0) != plen) exit(1); T.c_next = seq + (u32)plen; tcp_out(T.s_iss + 1 + (u32)T.sent_off, T.c_next, 0x10, 0, 0, 0); tls_pump(300); if (T.acked_off >= T.sent_off) send_window(); }
        else tcp_out(T.s_iss + 1 + (u32)T.sent_off, T.c_next, 0x10, 0, 0, 0); return;
    }
    if (fl & 0x10) { u32 a = ack - (T.s_iss + 1); if (a <= (u32)T.rlen + 1 && a > T.acked_off) T.acked_off = a; if (T.acked_off >= T.sent_off) send_window(); }
    if (fl & 1) { tcp_out(T.s_iss + 1 + (u32)T.rlen + (u32)(T.fin_sent ? 1 : 0), seq + 1, 0x10, 0, 0, 0); T.st = 0; if (tsock >= 0) { close(tsock); tsock = -1; } }
}
static void srv_tcp(const u8 *s, int n) {
    int dp = s[2] << 8 | s[3]; u32 seq = (u32)s[4] << 24 | (u32)s[5] << 16 | (u32)s[6] << 8 | s[7], ack = (u32)s[8] << 24 | (u32)s[9] << 16 | (u32)s[10] << 8 | s[11]; int fl = s[13], off = (s[12] >> 4) * 4, plen = n - off;
    T.cport = (u16)(s[0] << 8 | s[1]); T.sport = (u16)dp;
    if (dp == 443) { srv_tls_tcp(s, n); return; }
    if (dp == 81) { tcp_out(0, seq + 1, 0x14, 0, 0, 0); return; }                           /* closed port: RST */
    if (dp != 80) return;
    if ((fl & 2) && !(fl & 0x10)) { if (drop_syn) { drop_syn = 0; return; } syn_seen++; T.st = 1; T.c_next = seq + 1; T.s_iss = 0x1000; T.rlen = 0; tcp_out(T.s_iss, T.c_next, 0x12, 0, 0, 0); return; }
    if (T.st == 0) return;
    if (plen > 0) {
        if (seq == T.c_next && T.rlen == 0) {
            if (drop_req) { drop_req = 0; return; } req_seen++; char path[200]; int k = 0, p = off + 4; while (p < n && s[p] != ' ' && k < 199) path[k++] = (char)s[p++]; path[k] = 0; T.c_next = seq + (u32)plen; build_resp(path);
            tcp_out(T.s_iss + 1, T.c_next, 0x10, 0, 0, 0); if (swap_order && T.rlen > 3000) { /* send segments 1 and 2 swapped: client must drop the early one and wait for retransmission */
                int n1 = 1400; tcp_out(T.s_iss + 1 + 1400, T.c_next, 0x18, T.resp + 1400, n1, 0); tcp_out(T.s_iss + 1, T.c_next, 0x18, T.resp, n1, 0); T.sent_off = 2800; T.last_send = fake_ms; } else send_window();
        } else tcp_out(T.s_iss + 1, T.c_next, 0x10, 0, 0, 0);
        return;
    }
    if (fl & 0x10) { u32 a = ack - (T.s_iss + 1); if (a <= (u32)T.rlen + 1 && a > T.acked_off) T.acked_off = a; if (T.acked_off >= T.sent_off && T.sent_off < (u32)T.rlen) send_window(); }
    if (fl & 1) { tcp_out(T.s_iss + 1 + (u32)T.rlen + 1, seq + 1, 0x10, 0, 0, 0); T.st = 0; }
}
static void peer_tick(void) { if (T.st && T.tls) { tls_pump(1); if (T.acked_off >= T.sent_off) send_window(); } if (T.st && T.rlen && T.acked_off < T.sent_off && fake_ms - T.last_send > 300) { T.sent_off = T.acked_off; send_window(); } }
static int peer_ping_seen, peer_arp_replies, peer_icmp_replies;
static void peer_rx(const u8 *f, int n) {
    if (n < 14) return; int et = f[12] << 8 | f[13];
    if (et == 0x0806) { if (f[21] == 1 && !memcmp(f + 38, GW_IP, 4)) { memcpy(cl_mac, f + 22, 6); u8 r[60]; memset(r, 0, 60); memcpy(r, f + 22, 6); memcpy(r + 6, GW_MAC, 6); r[12] = 8; r[13] = 6; r[15] = 1; r[16] = 8; r[18] = 6; r[19] = 4; r[21] = 2; memcpy(r + 22, GW_MAC, 6); memcpy(r + 28, GW_IP, 4); memcpy(r + 32, f + 22, 6); memcpy(r + 38, f + 28, 4); enq(r, 60); }
        else if (f[21] == 2) peer_arp_replies++; return; }
    if (et != 0x0800) return; const u8 *ip = f + 14; int ihl = (ip[0] & 15) * 4, tl = ip[2] << 8 | ip[3]; memcpy(cl_mac, f + 6, 6);
    if (ck_fin(ck_acc(ip, ihl, 0)) != 0) { peer_bad++; return; } const u8 *pl = ip + ihl; int plen = tl - ihl;
    if (!(ip[6] & 0x40)) peer_bad++;                                                              /* we always set DF */
    if (ip[9] == 1) { if (pl[0] == 8) { if (ck_fin(ck_acc(pl, plen, 0)) != 0) { peer_bad++; return; } peer_ping_seen++; if (!memcmp(ip + 16, PING_IP, 4) || !memcmp(ip + 16, GW_IP, 4)) { u8 r[200]; memcpy(r, pl, (size_t)plen); r[0] = 0; r[2] = r[3] = 0; u16 c = ck_fin(ck_acc(r, plen, 0)); r[2] = (u8)(c >> 8); r[3] = (u8)c; ip_out(GW_MAC, ip + 16, ip + 12, 1, r, plen, 0); } }
        else if (pl[0] == 0) peer_icmp_replies++; return; }
    if (ip[9] == 17) { if (ck_l4(ip + 12, ip + 16, 17, pl, plen) != 0) { peer_bad++; return; } int dp = pl[2] << 8 | pl[3], sp = pl[0] << 8 | pl[1]; if (dp == 67) srv_dhcp(pl + 8, plen - 8); else if (dp == 53) srv_dns(pl + 8, plen - 8, sp); return; }
    if (ip[9] == 6) { if (ck_l4(ip + 12, ip + 16, 6, pl, plen) != 0) { peer_bad++; return; } if (!memcmp(ip + 16, WEB_IP, 4)) srv_tcp(pl, plen); }
}

#ifdef NIC_MODEL
/* ---------- register-level models of the two network cards, so the REAL drivers in netdrv.h run ---------- */
#define NET_HOST_MODEL 1
static u32 pci_rd(int bus, int dev, int fn, int off); static u8 inb(u16 p); static u32 inl(u16 p); static u16 net_inw(u16 p); static void outb(u16 p, u8 v); static void outw(u16 p, u16 v); static void outl(u16 p, u32 v);
#include "../netdrv.h"
static const u8 MODEL_MAC[6] = {0x52, 0x54, 0x00, 0x12, 0x34, 0x56};
static u32 cfg_addr, pci_cmd; static int nic_tx_frames, nic_rx_frames;
static u32 pci_rd(int bus, int dev, int fn, int off) {
    if (bus != 0 || dev != 3 || fn != 0) return 0xFFFFFFFFu;
    switch (off & 0xFC) { case 0: return NIC_KIND == 0 ? 0x100E8086u : 0x813910ECu; case 4: return pci_cmd; case 8: return 0x02000000u; case 0x0C: return 0; case 0x10: return NIC_KIND == 0 ? 0xFEBC0000u : 0xC001u; }
    return 0;
}
/* e1000 */
static u32 e1k_regs[0x6000 / 4]; static u32 e1k_rdh, e1k_tdh;
static u32 e1k_r(u32 reg) { if (reg == 0x8) return 2; if (reg == 0x5400) return MODEL_MAC[0] | MODEL_MAC[1] << 8 | MODEL_MAC[2] << 16 | (u32)MODEL_MAC[3] << 24; if (reg == 0x5404) return MODEL_MAC[4] | MODEL_MAC[5] << 8 | 0x80000000u; return e1k_regs[reg >> 2]; }
static void e1k_w(u32 reg, u32 v) {
    e1k_regs[reg >> 2] = v; if (reg == 0 && (v & (1u << 26))) e1k_regs[0] = v & ~(1u << 26);
    if (reg == 0x3818) { u32 n = e1k_regs[0x3808 >> 2] / 16; E1kTx *ring = (E1kTx *)(unsigned long)e1k_regs[0x3800 >> 2]; if (!(e1k_regs[0x400 >> 2] & 2)) return;
        while (e1k_tdh != v % n) { E1kTx *d = &ring[e1k_tdh]; if (d->cmd != 0x0B || d->len > 1514) { printf("model: bad TX descriptor\n"); exit(1); } peer_rx((const u8 *)(unsigned long)d->lo, d->len); nic_tx_frames++; d->status |= 1; e1k_tdh = (e1k_tdh + 1) % n; } }
}
/* RTL8139 */
static u8 rtl_cr = 1; static u32 rtl_rbstart, rtl_tsad[4], rtl_tsd[4], rtl_wp, rtl_capr, rtl_rcr;
static u8 inb(u16 p) { if (p == 0xCFC || p < 0xC000) return 0; u16 r = (u16)(p - 0xC000); if (r < 6) return MODEL_MAC[r]; if (r == 0x37) { int empty = (((rtl_capr + 16) & 0x1FFF) == rtl_wp); return (u8)((rtl_cr & ~1) | (empty ? 1 : 0)); } return 0; }
static u32 inl(u16 p) { if (p >= 0xC010 && p < 0xC020) return rtl_tsd[(p - 0xC010) / 4]; return 0; }
static u16 net_inw(u16 p) { if (p == 0xC03A) return (u16)rtl_wp; return 0; }
static void outb(u16 p, u8 v) { if (p < 0xC000) return; u16 r = (u16)(p - 0xC000); if (r == 0x37) { rtl_cr = v & ~0x10; if (v & 0x10) rtl_wp = rtl_capr = 0; } }
static void outw(u16 p, u16 v) { if (p == 0xC038) rtl_capr = v; }
static void outl(u16 p, u32 v) {
    if (p == 0xCF8) { cfg_addr = v; return; } if (p == 0xCFC) { if ((cfg_addr & 0xFC) == 4) pci_cmd = v; return; }
    if (p == 0xC030) rtl_rbstart = v; else if (p == 0xC044) rtl_rcr = v;
    else if (p >= 0xC020 && p < 0xC030) rtl_tsad[(p - 0xC020) / 4] = v;
    else if (p >= 0xC010 && p < 0xC020) { int i = (p - 0xC010) / 4; if (!(rtl_cr & 4)) return; peer_rx((const u8 *)(unsigned long)rtl_tsad[i], (int)(v & 0x1FFF)); nic_tx_frames++; rtl_tsd[i] = v | 0xA000; }
}
static void model_service(void) {
    if (!(pci_cmd & 4)) return;                                                           /* bus mastering must have been enabled by the driver */
    if (NIC_KIND == 0) {
        if (!(e1k_regs[0x100 >> 2] & 2)) return; u32 n = e1k_regs[0x2808 >> 2] / 16, rdt = e1k_regs[0x2818 >> 2]; E1kRx *ring = (E1kRx *)(unsigned long)e1k_regs[0x2800 >> 2]; if (!n) return;
        while (qh != qt && e1k_rdh != rdt % n) { E1kRx *d = &ring[e1k_rdh]; if (d->status & 1) { printf("model: driver left a DD descriptor unreleased\n"); exit(1); } memcpy((void *)(unsigned long)d->lo, q[qh], (size_t)ql[qh]); d->len = (u16)ql[qh]; d->status = 3; d->err = 0; qh = (qh + 1) & 63; e1k_rdh = (e1k_rdh + 1) % n; nic_rx_frames++; }
    } else {
        if (!(rtl_cr & 8) || !rtl_rbstart) return;
        while (qh != qt) { int n = ql[qh]; u32 used = (rtl_wp - ((rtl_capr + 16) & 0x1FFF)) & 0x1FFF; if (used + (u32)n + 8 > 8000) return;      /* ring full: the chip would drop; wait instead */
            u8 *h = (u8 *)(unsigned long)rtl_rbstart + rtl_wp; h[0] = 1; h[1] = 0; h[2] = (u8)((n + 4) & 255); h[3] = (u8)((n + 4) >> 8); memcpy(h + 4, q[qh], (size_t)n); memset(h + 4 + n, 0, 4);
            rtl_wp = (rtl_wp + 4 + (u32)n + 4 + 3) & ~3u; if (rtl_wp >= 8192) rtl_wp -= 8192; qh = (qh + 1) & 63; nic_rx_frames++; }
    }
}
#endif
static int nic_send(const u8 *f, int n) { peer_rx(f, n); return 0; }
static int nic_recv(u8 *f, int max) { fake_ms++; peer_tick(); if (qh == qt) return 0; int n = ql[qh]; if (n > max) n = max; memcpy(f, q[qh], (size_t)n); qh = (qh + 1) & 63; return n; }
#ifdef TLS_BRIDGE
static const char *net_errname_tls(void) { return net_tls_errstr(); }
#endif
#define CHECK(x) do { if (!(x)) { printf("FAIL line %d: %s\n", __LINE__, #x); exit(1); } } while (0)
int main(void) {
    { const u8 v[8] = {0x00, 0x01, 0xf2, 0x03, 0xf4, 0xf5, 0xf6, 0xf7}; CHECK(net_csum(v, 8) == 0x220d && ck_fin(ck_acc(v, 8, 0)) == 0x220d); }   /* RFC 1071 test vector */
#ifdef NIC_MODEL
    CHECK(net_probe() == 1 && net_nic.up); CHECK(net_eq(net_nic.mac, MODEL_MAC, 6)); CHECK(pci_cmd & 4); printf("driver under test: %s\n", net_nic.name);
#else
    net_nic.send = nic_send; net_nic.recv = nic_recv; net_nic.up = 1; u8 m[6] = {0x52, 0x54, 0, 0x12, 0x34, 0x56}; memcpy(net_nic.mac, m, 6);
#endif
    /* DHCP (first DISCOVER is lost) */
    CHECK(net_dhcp() == 0 && net_cfg); CHECK(net_eq(net_ip, CL_IP, 4) && net_eq(net_gw, GW_IP, 4) && net_eq(net_dns, GW_IP, 4) && net_mask[2] == 255 && net_mask[3] == 0 && net_lease == 3600);
    /* ping: on-link (needs ARP), off-link via gateway, and an unanswered address */
    u32 rtt; CHECK(net_ping(GW_IP, &rtt) == 0); CHECK(net_ping(PING_IP, &rtt) == 0); u8 dead[4] = {8, 8, 4, 4}; CHECK(net_ping(dead, &rtt) == -4);
    /* DNS */
    u8 ip[4]; CHECK(net_resolve("example.test", ip) == 0 && net_eq(ip, WEB_IP, 4)); CHECK(net_resolve("cname.test", ip) == 0 && net_eq(ip, WEB_IP, 4));
    CHECK(net_resolve("nx.test", ip) == -5); CHECK(net_resolve("silent.test", ip) == -4); CHECK(net_resolve("10.1.2.3", ip) == 0 && ip[0] == 10 && ip[3] == 3); CHECK(net_resolve("bad..name", ip) != 0);
    /* HTTP with a lost SYN, a lost request and out-of-order response segments */
    CHECK(net_http_get("http://example.test/") == 0); CHECK(net_hstatus == 200 && net_blen == 5000 && !net_htrunc);
    for (int i = 0; i < 5000; i++) CHECK(net_body[i] == (u8)('a' + i % 26)); CHECK(syn_seen == 1 && req_seen == 1);
    CHECK(net_http_get("http://example.test/chunked") == 0); CHECK(net_hstatus == 200 && net_blen == 23 && !memcmp(net_body, "Wikipedia in\r\n\r\nchunks.", 23));
    CHECK(net_http_get("http://example.test/redir") == 0 && net_hstatus == 200 && !strncmp((const char *)net_body, "<html><body>final page", 22));
    CHECK(net_http_get("http://example.test/missing") == 0 && net_hstatus == 404);
    swap_order = 0; CHECK(net_http_get("http://example.test/big") == 0); CHECK(net_hstatus == 200 && net_blen > 50000 && net_htrunc);       /* buffer is 60000: reported as truncated, not crashed */
    CHECK(net_http_get("http://example.test:81/") == -5);                                                                                    /* connection refused */
#ifndef TLS_BRIDGE
    CHECK(net_http_get("https://example.test/") == -2);
#endif
    CHECK(net_http_get("http://nx.test/") == -3);
    /* the stack must answer the peer: ARP request for us, and a ping */
    { u8 r[60]; memset(r, 0, 60); memset(r, 255, 6); memcpy(r + 6, GW_MAC, 6); r[12] = 8; r[13] = 6; r[15] = 1; r[16] = 8; r[18] = 6; r[19] = 4; r[21] = 1; memcpy(r + 22, GW_MAC, 6); memcpy(r + 28, GW_IP, 4); memcpy(r + 38, CL_IP, 4); enq(r, 60);
      u8 p[40]; memset(p, 0, 40); p[0] = 8; p[5] = 7; p[7] = 1; u16 c = ck_fin(ck_acc(p, 40, 0)); p[2] = (u8)(c >> 8); p[3] = (u8)c; ip_out(net_nic.mac, GW_IP, CL_IP, 1, p, 40, 0);
      int a0 = peer_arp_replies, i0 = peer_icmp_replies; for (int i = 0; i < 20; i++) { (void)now_ms(); net_poll(); } CHECK(peer_arp_replies == a0 + 1); (void)i0; }
    /* corrupt packets are ignored and counted */
    { u32 bad0 = net_stat_bad; u8 p[40]; memset(p, 0, 40); p[0] = 8; ip_out(net_nic.mac, GW_IP, CL_IP, 1, p, 40, 1); for (int i = 0; i < 5; i++) { (void)now_ms(); net_poll(); } CHECK(net_stat_bad == bad0 + 1); }
    CHECK(peer_bad == 0);                                                              /* every packet WE sent had valid IP/UDP/TCP/ICMP checksums and DF set */
    #ifdef NIC_MODEL
    printf("frames through the driver: %d sent, %d received\n", nic_tx_frames, nic_rx_frames); CHECK(nic_tx_frames > 100 && nic_rx_frames > 100);
#endif
#ifdef TLS_BRIDGE
    { tls_port = atoi(getenv("TLS_PORT")); fake_ms += 0;
      CHECK(net_http_get("https://example.test/n/50000") == 0); CHECK(net_hs_tls && net_hstatus == 200 && net_blen == 50000 && !net_htrunc); for (int i = 0; i < 50000; i++) CHECK(net_body[i] == (u8)((i * 7 + 3) % 251));
      CHECK(net_http_get("https://example.test/n/3000") == 0 && net_blen == 3000 && net_hstatus == 200);                  /* a second connection right after the first */
      CHECK(net_http_get("https://example.test/missing") == 0 && net_hstatus == 404);
      CHECK(net_http_get("https://example.test/n/200000") == 0 && net_hstatus == 200 && net_htrunc && net_blen > 50000); for (int i = 0; i < 1000; i++) CHECK(net_body[i] == (u8)((i * 7 + 3) % 251));   /* bigger than our buffer: cut, flagged, no crash */
      CHECK(net_http_get("http://example.test/") == 0 && !net_hs_tls && net_blen == 5000);                                  /* plain http still works afterwards */
      tls_flip_at = 3000; CHECK(net_http_get("https://example.test/n/9000") == -7); CHECK(strstr(net_errname_tls(), "MAC") != 0); tls_flip_at = -1;   /* a flipped bit in the encrypted stream is detected */
      CHECK(net_http_get("https://example.test/n/10") == 0 && net_blen == 10);                                              /* and the stack recovers */
      printf("https through the full stack (TCP + TLS 1.3 + HTTP) vs real OpenSSL: PASS\n"); }
#endif
    printf("network stack tests: PASS (DHCP, ARP, ping, DNS incl. CNAME/NXDOMAIN/timeout, TCP with loss + reordering, HTTP, redirect, chunked, refused, https refusal)\n"); return 0;
}
