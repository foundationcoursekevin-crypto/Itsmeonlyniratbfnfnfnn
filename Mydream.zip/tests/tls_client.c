/* Host test client: runs tls.h + crypto.h over a real TCP socket against a real TLS server (Python/OpenSSL).
   usage: tls_client PORT HOST PATH [flip_at_byte] ; prints RESULT lines for tests/tls_interop.py */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <poll.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
typedef unsigned char u8; typedef unsigned short u16; typedef unsigned int u32;
#include "../crypto.h"
#include "../tls.h"
static int fd; static u8 rb[400000]; static int rn; static long flip_at = -1, total;
static int io_write(const u8 *d, int n) { return send(fd, d, (size_t)n, 0) == n ? 0 : -1; }
static int io_need(int n, u32 ms) { while (rn < n) { struct pollfd p = {fd, POLLIN, 0}; if (poll(&p, 1, (int)ms) <= 0) return 0; int k = (int)recv(fd, rb + rn, sizeof rb - (size_t)rn, 0); if (k <= 0) return 0; if (flip_at >= total && flip_at < total + k) rb[rn + (flip_at - total)] ^= 1; total += k; rn += k; } return 1; }
static const u8 *io_data(void) { return rb; }
static void io_eat(int n) { memmove(rb, rb + n, (size_t)(rn - n)); rn -= n; }
int main(int argc, char **argv) {
    int port = atoi(argv[1]); const char *host = argv[2], *path = argv[3]; if (argc > 4) flip_at = atol(argv[4]);
    fd = socket(AF_INET, SOCK_STREAM, 0); struct sockaddr_in a = {0}; a.sin_family = AF_INET; a.sin_port = htons((u16)port); inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
    if (connect(fd, (struct sockaddr *)&a, sizeof a)) { printf("RESULT connect-failed\n"); return 1; }
    tls_io.write = io_write; tls_io.need = io_need; tls_io.data = io_data; tls_io.eat = io_eat;
    int r = tls_connect(host); if (r) { printf("RESULT handshake-failed %d %s\n", r, tls.err); return 0; }
    char req[300]; int n = snprintf(req, sizeof req, "GET %s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\n\r\n", path, host); if (tls_write((u8 *)req, n)) { printf("RESULT write-failed\n"); return 1; }
    static u8 body[300000]; int got = 0, cut = 0; for (;;) { int k = tls_read(body + got, (int)sizeof body - got, &cut, 5000); if (k > 0) got += k; else { if (k < 0) { printf("RESULT read-error %d %s\n", k, tls.err); return 0; } break; } }
    tls_close(); body[got < (int)sizeof body ? got : (int)sizeof body - 1] = 0; u8 h[32]; sha256(body, (u32)got, h); printf("RESULT ok %d ", got); for (int i = 0; i < 32; i++) printf("%02x", h[i]); printf(" cut=%d\n", cut); return 0;
}
