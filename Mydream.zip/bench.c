#define HOSTTEST 1
#include "kernel.c"
#include <stdio.h>
#include <time.h>
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec*1000.0+t.tv_nsec/1e6;}
int main(int argc,char**argv){
  mem_kb = (argc>1)?2u*1024*1024:4u*1024*1024;
  W=1366;H=768;PITCH=W*4;mx=pmx=683;my=pmy=384;
  kernel_init(); isl_expand=0;timer_on=0;
  double t=now(); build_scene(); printf("build_scene %.1f ms\n",now()-t);
  compose(1000);
  t=now(); for(int i=0;i<50;i++) compose(1000+i*16); printf("idle compose %.2f ms\n",(now()-t)/50);
  app_at(1)->open(); task_sync(); app_at(3)->open(); task_sync(); app_at(7)->open(); task_sync();
  compose(2000);
  t=now(); for(int i=0;i<400;i++) compose(2000+i*16); printf("3 windows compose %.2f ms\n",(now()-t)/400);
  return 0;}
