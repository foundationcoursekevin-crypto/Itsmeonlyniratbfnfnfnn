# PixelBeeOS 3.0 — Portable USB Storage Engineering Status

## Source baseline
This package is based on the supplied PixelBeeOS 2.14 source archive. The existing kernel still identifies itself internally as PixelBeeOS 2.11 Turbo in several UI strings.

## Verified baseline
- `make`: kernel compiles and links successfully with the included 32-bit freestanding toolchain.
- `make host-test`: existing host-side UI regression checks pass.
- Current filesystem: fixed-size in-memory RAM filesystem (`NODES=96`, `FSIZE=2048`); all file data is volatile.
- Current memory support: bootloader-reported memory size and a low-memory frame-rate profile only. Paging and a virtual-memory allocator are not implemented.
- PCI enumeration can detect a storage-class controller, but the kernel reports that its driver is unavailable.
- README notes that native USB HID controller drivers are not included.

## Portable-storage goal (not yet implemented)
A real portable installation needs all of the following before it can safely claim persistent USB files:
1. USB host-controller support for target machines (at minimum a tested USB 2.0 EHCI path, plus UHCI/OHCI compatibility where needed; xHCI for newer machines).
2. USB Mass Storage Class Bulk-Only Transport (BOT), SCSI INQUIRY/READ CAPACITY/READ(10)/WRITE(10), reset recovery and timeouts.
3. A block-device layer with sector bounds checking, write ordering and error reporting.
4. FAT32 (or another documented filesystem) mount/read/write support, including allocation tables, directory entries, long filenames and clean unmount.
5. A persistent user-data partition on the boot USB, separate from boot files; never overwrite an unknown disk automatically.
6. Factory-reset flow that asks for confirmation and formats only the designated PixelBeeOS data partition, preserving boot/recovery files.
7. Power-loss tests, filesystem consistency tests, and real-hardware tests on each supported controller family.

## Safety and data-integrity status
**Do not use this build to store important files.** It does not yet mount or write USB storage. Files created in the current C: RAM disk disappear on reboot or shutdown. No factory-reset operation is provided. The package must not be advertised as portable-persistent or boot-tested.

## Memory-management work still required
The current Multiboot entry receives the Multiboot information pointer, but the kernel does not yet initialize a physical page allocator, page tables, kernel heap, user address spaces, swap, or an OOM policy. Those components require a memory-map parser and reserved-region accounting before paging is enabled.

## Build verification
Run `make` and `make host-test` in this directory. `make iso` additionally requires GRUB rescue tools and xorriso. A successful compile is not proof of a physical hardware boot.
