PixelBeeOS 2.12 - Hardware Input Reliability Update
====================================================

Input support in this build
---------------------------
- Direct 8042 PS/2 controller polling for a standard PS/2 keyboard and mouse.
- Keyboard setup now disables scanning during setup, issues a keyboard reset,
  consumes the BAT completion byte, handles ACK/RESEND replies, and enables
  scanning again.
- Existing mouse setup resets the PS/2 mouse, selects defaults, and enables
  streaming. Mouse packets are decoded by the kernel's polling loop.
- No external driver package is required for these legacy PS/2 devices.

USB keyboard and mouse compatibility
------------------------------------
This release does NOT contain native USB HID host-controller drivers
(UHCI/OHCI/EHCI/xHCI). The kernel can enumerate PCI devices for display only;
that is not USB input support.

For a USB keyboard or mouse, enter the PC firmware/BIOS setup and enable a
setting named "USB Legacy Support", "Legacy USB", or "USB Keyboard/Mouse
Support" if the firmware offers it. This asks firmware to expose USB input
through the legacy PS/2-compatible interface. Availability and behavior vary
by PC. If the setting is absent or does not work, USB input will not work in
this build; use a genuine PS/2 device/controller or wait for native USB HID
support to be implemented.

Build and test
--------------
make            builds kernel.elf
make host-test  runs host-side UI regression checks
make iso        creates pixelbeeos.iso (requires GRUB tools and xorriso)
make run        boots the ISO in QEMU

Hardware validation
-------------------
The build can be compiled and host-tested here, but real keyboard/mouse
operation must still be verified on the target PC. Test first from a USB
keyboard with BIOS legacy support enabled, or a PS/2 keyboard and mouse.
This is a small freestanding 32-bit kernel, not a Linux-based OS; it cannot
inherit Linux USB drivers.
