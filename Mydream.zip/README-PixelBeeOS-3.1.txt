PIXELBEEOS 3.1 - LIQUID GLASS DESKTOP
=====================================
Based on the 3.0 / 2.14 source.

NEW
- liquid_panel(): clear glass with an edge lens (backdrop bends inward, red/blue colour fringing),
  bright specular rim, inner glow and a soft top highlight. Only the edge band does per-pixel work.
- Applied to the desktop only: dock (full pill), clock/date and status pills, Launchpad,
  Control Center, Spotlight launcher and desktop right-click menus.
- New default wallpaper theme "liquid" (vivid blue / pink / orange / violet) so the glass has colour to refract.
  Pick any theme from Settings or the `theme` command.
- App windows and the Terminal stay solid, as before.

UNCHANGED / STILL MISSING (see PIXELBEEOS-3.0-PORTABLE-STORAGE-STATUS.md)
- Files are still stored in RAM only and vanish on shutdown.
- No USB / disk driver, no network stack, no paging, no ELF loader.

BUILD: make | make host-test | make host-preview | make iso (needs GRUB tools; GitHub Actions workflow included)
Verified: freestanding kernel compiles and links, host UI tests pass. Not boot-tested on real hardware.

PERSISTENT STORAGE (new)
- fat32.h / ata.h / disk.h: FAT32 + ATA PIO + the `disk` command. See PIXELBEEOS-3.1-STORAGE-STATUS.md.
- Files can now be saved to a real disk and survive power-off: disk mount, disk save, disk unmount.
- Verified with host tests and an independent FAT32 checker; NOT yet run on real hardware or in QEMU.
- USB sticks are NOT supported yet (no USB driver).

INTERNET (new)
- net.h / netdrv.h / netcmd.h: e1000 + RTL8139 drivers, ARP/IP/ICMP/UDP/DHCP/DNS/TCP/HTTP, commands net, ping, dns, http, get.
- BeeBrowser loads real http:// and https:// pages. HTTPS = TLS 1.3, encrypted but the server certificate is NOT verified yet. See PIXELBEEOS-3.1-NETWORK-STATUS.md.
- make run now adds -nic user,model=e1000. make test-network runs the network tests.
- crypto.h / tls.h / nettls.h: TLS 1.3 client. make test-tls runs the crypto/OpenSSL interop tests.
- Network app (netapp.h): click-to-connect panel, tray status icon, Control Center tile, auto-connect at startup.

LOOK
- NEW default theme "frost" (clear liquid glass on desktop surfaces only: dock, pills, Launchpad, Control Center, Spotlight, menus; app windows and the Terminal stay solid): calm deep-navy wallpaper with soft muted light blooms, and clear desktop glass (2px blur, 20% white fill, soft translucent border, white inner glow; rounded-rectangle dock). Older themes keep the previous lens glass.
- ANIMATIONS: windows scale up, fade in and rise when opened or restored; closing a window shrinks and fades it, minimizing flies it into the dock; Launchpad, Search, Control Center and the desktop menu fade and rise into place. Skipped in Performance mode.
- SHELL: pipes (cmd | grep TEXT | sort | uniq | head N | tail N | wc, grep -v hides matches), script files (run FILE: one command per line, # comments, if A == B / if exists FILE, exit), alias/unalias, variables via set NAME VALUE and %NAME%. Try: run Demo-Script.txt (in Home) or type pipes.
- LIQUID GLASS: desktop glass now uses the real lens recipe of Kyant AndroidLiquidGlass (backdrop; Apache-2.0): rounded-rect SDF refraction that bends the wallpaper near the edges (circleMap curve), vibrancy, translucent surface and a 45-degree rim highlight, ported to integer math. The wallpaper is a soft layered-ribbon design so the bending is visible.
- DOCK: macOS-style dock: frosted rounded bar, large vivid gradient icons, running-app dots, separators, hover magnification and name labels. Wallpaper colours are more vivid.
- INPUT: if no PS/2 keyboard or mouse answers at boot (a PC with USB-only devices), an on-screen notice explains the BIOS setting (Legacy USB Support / CSM). USB HID drivers are not implemented yet.
- EDITOR: Notes is now a real text editor: arrow keys move the cursor, insert/delete anywhere, line numbers, current-line highlight, Ln/Col and character count, scrolls to follow the cursor. Open files from Files or with: edit NAME.
- SHELL (more): output redirection for any command (list > out.txt, cmd | grep x >> log.txt) and loops: for n in 1..5 do echo %n%  /  for x in a b c do ...
- SPEED: terminal scrolling uses fast block moves.
- Previous default theme was "slate": a calm, professional dark slate gradient with dithering (no banding), neutral crisp glass, one muted accent.
- The vivid look is still available: Settings > Appearance > liquid, or the terminal command: theme liquid.
PixelBeeOS 3.2 Dock & Clarity polish
- Dock magnification now has a broader, stronger smooth hover response.
- Increased hover-zone height and radius for more forgiving mouse interaction.
- Dock glass tint is cleaner/brighter with reduced muddy dark overlay.
- Running indicators have a gentle luminance pulse.
- Hover labels use a higher-contrast graphite glass treatment and clearer white text.
- Low-RAM/host checks remain passing.
