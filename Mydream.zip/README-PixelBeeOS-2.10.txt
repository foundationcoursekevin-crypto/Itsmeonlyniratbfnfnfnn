PixelBeeOS 2.10 - 2 GB Lite Edition
==================================

This update adds an automatic low-memory profile for older laptops with 2 GB RAM.

2 GB Lite profile
-----------------
- Automatically selected when the bootloader reports 3 GB RAM or less.
- Keeps the blue water-glass appearance (does not force a flat/opaque UI).
- Reduces desktop blur radius from 8 to 2 and slightly lowers tint work.
- Uses a 30 FPS redraw/animation budget (33 ms) to reduce CPU load.
- Normal-memory systems retain the balanced 60 FPS target and richer glass blur.
- Settings > Performance Mode remains available as an optional maximum-speed,
  flat-UI mode; turning it off restores the appropriate automatic profile.
- GRUB prefers 1280x720, then 1024x768 and 800x600 to reduce framebuffer work
  on older hardware.

Build and test
--------------
- make: builds the 32-bit freestanding kernel.elf
- make host-test: runs desktop and low-memory profile regression checks
- make host-preview: builds the host-side C renderer
- make iso: creates a GRUB ISO if grub-mkrescue and xorriso are installed

Performance notes
-----------------
The low-memory profile reduces graphics work; it cannot guarantee perfectly
smooth performance on every 2 GB PC. CPU speed, graphics hardware, firmware,
resolution, and driver support still matter. This is an experimental hobby OS.
The filesystem remains RAM-backed in this source build; persistent disk storage,
full hardware drivers, preemptive multitasking and virtual memory are not included.
A successful compile and host tests are not a physical-PC boot/performance test.
