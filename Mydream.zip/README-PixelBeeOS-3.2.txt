PIXELBEEOS 3.2 - COMPATIBILITY + SMOOTH GRAPHICS
================================================
Based on 3.1 Liquid Glass. Nothing was removed.

BOOTS ON MORE PCs
- Any screen: the kernel no longer demands exactly 1366x768x32. It accepts 32, 24, 16 and 15 bits per pixel,
  RGB or BGR channel order (colours were wrong/blank on some GPUs before), and any resolution.
- Big screens: the UI buffers now go up to 1920x1200. Anything larger (4K...) is centred with black borders
  instead of being cropped into the top-left corner.
- grub.cfg: new boot menu (3 s). Entry 1 = automatic (tries 1920x1200 down to 800x600). If the screen is blank, wrong
  size or garbled, reboot and pick "Safe graphics 1024x768" or "Safe graphics 800x600".
- If no usable graphics mode is given, a text-mode message now explains what to do (it used to say "needs 32-bit").
- UEFI: the CI workflow now installs grub-efi-amd64-bin and grub-efi-ia32-bin, so grub-mkrescue builds a hybrid ISO
  (BIOS + UEFI). Before, the ISO was BIOS-only and modern UEFI-only PCs could not boot it.
- 16 bpp panels get ordered dithering so the gradients do not band. (display.h, tests/display_test.c)

SHUTDOWN / RESTART ON REAL HARDWARE (acpi.h)
- shutdown now reads the firmware's ACPI tables (RSDP > RSDT > FADT > DSDT \_S5_), enables ACPI mode if needed and
  writes the sleep type to PM1a/PM1b. Before only QEMU/Bochs/VirtualBox ports were poked, so real PCs stayed on
  "safe to turn off". restart uses the FADT reset register, then the old keyboard-controller / chipset resets.
- Tested against synthetic tables (make test-acpi). Table discovery works on BIOS/CSM boot; GRUB's Multiboot 1
  handoff on pure UEFI does not pass the ACPI pointer, so there shutdown may still stop on the message screen.

KEYBOARD
- Number pad works (digits, + - * /, ., Enter, Num Lock; arrows when Num Lock is off), extra ISO key (\ |).

MORE FEATURES
- New app: Minesweeper (dock/Launchpad, or type mines). 9x9, 10 mines, first click always safe, flood-fill, timer,
  right-click or F to flag, arrows + Space/Enter for keyboard play, R restarts. (mines.h, make test-mines)
- Home, End, Delete, Page Up, Page Down keys (also keypad with Num Lock off). Notes editor uses all of them.

SMOOTHER GRAPHICS
- iOS-style fluid panels: Launchpad, Search, Control Center and menus now grow from ~94% with a small spring overshoot while
  fading and rising, and when closed they shrink and fade out (they used to vanish instantly). Bilinear, so edges stay smooth.
- Dock is now compact (38 px icons, was 52) with gentler magnification.
- Smooth hover: buttons, Launchpad tiles, list rows and calculator keys fade their highlight in and out (~90 ms) instead of snapping.
- Window open / close / minimize animations now use bilinear sampling (they were nearest-neighbour, so edges
  and text shimmered while scaling), and windows open with a small spring overshoot instead of a plain ease.
- Mouse pointer: smooth acceleration curve with sub-pixel carry (precise when slow, fast when flicked), and a new
  anti-aliased arrow with outline and soft drop shadow (drawn straight to the screen, never waits for a frame).
- Vsync: if the display has a working VGA retrace signal (auto-detected; QEMU, VirtualBox, VMware, many PCs) frames
  are written right after retrace to reduce tearing. Skipped automatically when the system is already running
  behind. Terminal command: vsync on|off (vsync alone shows the state). display now shows the colour depth.

NOT CHANGED (still missing, see 3.0/3.1 status files)
- USB keyboard/mouse (still PS/2 or BIOS "Legacy USB Support"), real Wi-Fi, audio, paging, ELF loader.

HONEST TEST STATUS
- Built and tested on the host: make, make host-test, make test-acpi, make test-display. Screenshots rendered at
  800x600, 1024x768, 1366x768 and 1920x1080.
- NOT boot-tested in QEMU or on real hardware (no emulator was available while making this). Please try the ISO
  and tell me what you see, especially the safe-graphics entries, shutdown and the pointer.

PixelBeeOS 3.2 Dock refinement (2026-11-25)
- Refined dock hover magnification with a smoother bell-shaped integer interpolation and a stronger scale response.
- Dock width/spacing continues to adapt to scaled icon sizes.
- Hover label now includes a small pointer-tail detail.
- Updated kernel.elf and added a host-rendered desktop preview in screenshots/PixelBeeOS-3.2-dock-preview.png.
- Validation: kernel compile and host-test checks passed. This is not a hardware boot validation.
