PIXELBEEOS 3.0 — PORTABLE STORAGE DEVELOPMENT STATUS

This is an engineering-status package based on the supplied PixelBeeOS 2.14 source.
It is NOT a completed portable-persistent release.

Verified:
- Kernel compile/link: PASS
- Existing host UI tests: PASS

Not implemented:
- USB host-controller drivers / USB mass-storage BOT
- SCSI block-device driver
- FAT32 persistent filesystem
- Physical page allocator / paging / virtual-memory manager
- Factory-reset partition workflow

Current files remain in a volatile RAM filesystem and are lost at shutdown.
Do not store important data on this build. See
PIXELBEEOS-3.0-PORTABLE-STORAGE-STATUS.md for the required implementation plan.
