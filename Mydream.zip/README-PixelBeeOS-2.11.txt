PixelBeeOS 2.11 - Turbo Edition (glass UI update)
===============================

Goal: a smoother, faster desktop on the same hardware, with an identical look.

What changed
------------
- Packed colour blending: red+blue are blended in one 32-bit multiply and green
  in a second, instead of three separate multiplies/divides per pixel.
- Span blending: straight runs of every rounded rectangle (window shadows,
  title bars, panels, dock highlights) are blended one run at a time with the
  colour maths done once per run. Only the rounded corners use per-pixel maths.
- Result measured on the host build (1366x768, 3 app windows open): frame
  composition went from about 5.96 ms to about 1.97 ms (roughly 3x faster);
  idle desktop from 1.23 ms to 0.79 ms.
- Output is bit-identical: 12 desktop scenes (desktop, This PC, Control Center,
  Launchpad, Files, search, context menu, Mission Control, snapped windows,
  Terminal, multi-app, gallery) match the 2.10 renderer pixel for pixel.

Unchanged
---------
2 GB Lite auto profile, water-glass look, 30/60 FPS targets, Performance Mode.

Build and test
--------------
make            builds the 32-bit freestanding kernel.elf
make host-test  runs the regression checks
make iso        creates a GRUB ISO (needs grub-mkrescue and xorriso)

Honest limits
-------------
Host timings are from a modern PC; an old laptop will be slower in absolute
terms, but the relative saving applies. Not tested on physical hardware.
The filesystem is still RAM-backed (files vanish on reboot). Disk saving and an
ELF program loader are not included yet.

Glass UI update
---------------
- Removed the "New update available / Update Center" card.
- Taskbar (dock) is now neutral smoked frosted glass instead of blue water glass.
- New default wallpaper "bloom" (soft indigo light blooms) replaces the blue
  water-swoosh wallpaper. Other themes are unchanged.
- Desktop clock/date is now live from the hardware clock (was hard-coded text);
  fake "30C" weather removed.
- "cd desktop" (and documents, downloads, pictures...) now works from anywhere.

Input fix
---------
- More robust PS/2 (8042) bring-up for desktop PCs: ports quieted then re-enabled,
  clocks and scancode translation set, keyboard scanning enabled, mouse reset.
- If no PS/2 controller exists, the terminal now says so on screen.
- Native USB keyboard/mouse drivers are NOT included yet. USB devices only work
  when the BIOS emulates PS/2 ("USB Legacy Support" / "Legacy USB" enabled).

App look update
---------------
- Window chrome: tighter 14px corners, gradient title bar, fixed the title-bar
  corner glitch, softer shadows. Terminal uses the same chrome.
- Info apps (Monitor, Performance, Device Manager, Security Center, Settings)
  now use titled sections and rounded row cards.
- Settings theme tiles now fit the window at any size.
- Calendar footer no longer runs off the window.

Top bar removed
---------------
- The top menu bar (PixelBeeOS / Apps / Search / NET / BAT) is gone; windows can
  use the full screen height, maximize covers the whole display.
- Its useful functions moved into the dock: bee = Apps (Launchpad),
  magnifier = Search (Spotlight), sliders = Control Center, plus the existing
  power and restart buttons. Keyboard: Win+Space search, F3 / Win+Up Mission
  Control, Win+Left/Right snap, Win+L lock, Alt+Tab switch.
\n\n2.12 hardware-input follow-up: see README-PixelBeeOS-2.12.txt. The PS/2 keyboard reset/ACK path is more robust. Native USB HID host-controller drivers are still not included.\n