PixelBeeOS 2.9 - Files & Launchpad Update
========================================

Builds on PixelBeeOS 2.8 Core OS Edition. Retains the blue desktop, bee identity,
app windows, Terminal, Control Center, RAM-backed C: filesystem, lock screen,
Task Manager, Device Manager and Security Center.

New in 2.9
----------
- File Manager top ribbon now includes a translucent water-glass "+ New Folder"
  action beside New file and Up.
- New Folder opens a name-entry dialog. Type the folder name, press Enter to
  create it, or Esc to cancel. The folder is created inside the directory that
  is currently open in File Manager (not always on the Desktop).
- Launchpad now has a search field for applications, files and folders.
- Search matches names case-insensitively across the RAM filesystem and app list.
  Matching file/folder results are clickable; folders open in File Manager and
  text files open in the Notepad viewer. Matching apps launch directly.
- Press Enter in Launchpad to open the first matching file/folder or app; Esc
  closes Launchpad. Backspace edits the search query.
- Added regression checks for creating a folder in Documents and finding/opening
  files and folders through Launchpad.

Build and test
--------------
- `make` builds the 32-bit freestanding kernel.elf.
- `make host-test` runs the interaction and regression tests.
- `make host-preview` builds the host-side C renderer used for the included
  Launchpad search and New Folder UI screenshots.
- `make iso` creates a GRUB ISO if grub-mkrescue and xorriso are installed.
- `make run` launches the ISO in QEMU if QEMU is installed.

Important limitations
---------------------
The C: filesystem is still volatile RAM storage. New folders and files are not
preserved after power-off/reboot. Physical SSD/HDD persistence, a journaled disk
filesystem and storage drivers are not included. This remains an experimental
hobby kernel, not a Windows/Linux replacement. The UI task model is cooperative;
there is no preemptive process scheduler, virtual-memory paging, full device
support, multi-user isolation, per-file ACL system, network stack or firewall.
A successful build and host tests do not prove physical-PC boot compatibility.
