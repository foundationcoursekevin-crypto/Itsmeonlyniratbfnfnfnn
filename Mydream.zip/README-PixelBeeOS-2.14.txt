PIXELBEEOS 2.14 - COMPACT LAUNCHPAD
==================================

This release refines the Launchpad sizing to match the supplied compact
centered reference.

LAUNCHPAD CHANGES
-----------------
- Compact centered glass panel, capped at 660 pixels wide and 620 pixels tall.
- Five-column desktop app layout with responsive columns on smaller screens.
- App tiles are more subtle and icon-focused rather than large solid cards.
- Search for apps, files and folders remains available.
- Existing keyboard and mouse hit targets and Escape/Enter behavior are preserved.

PRESERVED
---------
- PS/2 keyboard and mouse initialization from the prior project.
- Existing applications, filesystem, desktop, window manager and low-RAM checks.

BUILD
-----
Run: make
Run host-side UI checks: make host-test
Build ISO (requires GRUB rescue tools): make iso

The freestanding kernel compiles and links, and host-side UI regression checks pass.
Physical PC boot and input compatibility still require testing on target hardware.
Native USB HID controller drivers are not included.
