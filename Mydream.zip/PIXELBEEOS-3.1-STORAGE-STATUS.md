# PixelBeeOS 3.1 - Persistent storage status

## What now exists (new in this build)
| Piece | File | How it was verified |
|---|---|---|
| Block-device layer with bounds checks | `fat32.h` | host tests, out-of-range access refused |
| FAT32: mount, read, create/overwrite, mkdir, delete, long file names, format | `fat32.h` | `tests/fat32_test.c` (ASan+UBSan, 300-file folder, 300 KB file, power-loss + I/O-failure injection) **and** an independent checker `tests/verify_fat32.py` that shares no code with the driver (chains, both FAT copies, LFN checksums, `.`/`..`, lost/cross-linked clusters, FSInfo, clean flag) |
| ATA (IDE) PIO disk driver, LBA28, timeouts | `ata.h` | `tests/ata_emu_test.c` against a software model of an IDE controller. **Not run on real hardware or QEMU yet.** |
| `disk` terminal command | `disk.h` | safe-with-no-hardware check in `make host-test` |

Run all of it: `make test-storage` and `make host-test`.

## Safety rules (enforced in code)
- Only a FAT32 volume labelled exactly `PIXELBEEDAT` is writable. Any other volume mounts read-only.
- Write order: data clusters, then FAT chain, then directory entry, then release old clusters. A power cut can leak space, never point a file at garbage.
- FAT clean-shutdown bit is cleared while mounted for writing, set by `disk unmount`; the next mount warns if it was not cleanly unmounted.
- `disk format D P ERASE-D-P` touches only that one partition, only if it is type FAT32/0xDA (never NTFS/Linux/unknown), and only after the typed confirmation. `disk reset ERASE` reformats only the mounted PIXELBEEDAT partition; boot files elsewhere on the disk are untouched.
- Probing a disk is read-only (IDENTIFY). Nothing is ever written unless you run a write command.

## Using it
```
disk list                     show disks and partitions
disk mount 0 1                mount disk 0, partition 1 as D:
disk save notes.txt /docs/notes.txt     copy a RAM file to the disk
disk load /docs/notes.txt     copy a disk file into RAM
disk ls /   |  disk cat /file  |  disk mkdir /x  |  disk rm /x
disk unmount                  flush and eject (do this before power off)
```
Create the data partition with any disk tool (MBR, type 0B or 0C), then `disk format D P ERASE-D-P`.

## NOT done yet (do not rely on these)
1. **USB sticks.** Needs xHCI/EHCI/UHCI host controllers + USB Mass Storage (Bulk-Only). This is the largest remaining piece and the one a portable-USB OS needs.
2. AHCI (SATA native mode) and NVMe disks. Today only IDE/"compatible mode" disks and VM IDE disks are visible.
3. LBA48 (disks larger than 128 GB are clamped to 128 GB).
4. Automatic mount at boot, and the Files app / `C:` drive using the disk. Right now persistence is explicit through `disk save/load`; the RAM disk is still volatile.
5. Real-hardware and real power-loss testing. The driver logic is verified against models, not metal.
6. Partition-table creation tool / USB image builder, and a file size limit lift (RAM files are still 2 KB).
