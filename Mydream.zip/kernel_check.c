#define HOSTTEST 1
#include "kernel.c"
#include <stdio.h>

static int hit_exists(int id) {
    for (int j = 0; j < nhits; j++) if (hits[j].id == id) return 1;
    return 0;
}
static int desktop_hits_fit(void) {
    for (int i = 0; i < 6; i++) {
        int found = 0;
        for (int j = 0; j < nhits; j++) if (hits[j].id == 3000 + i) {
            Hit h = hits[j]; found = 1;
            if (h.x < 0 || h.y < 38 || h.x + h.w > (int)W || h.y + h.h > (int)H) return 0;
            break;
        }
        if (!found) return 0;
    }
    return 1;
}
static int desktop_apps_fit(void) {
    for (int i = 0; i <= app_count(); i++) {
        int found = 0;
        for (int j = 0; j < nhits; j++) if (hits[j].id == 1700 + i) {
            Hit h = hits[j]; found = 1;
            if (h.x < 0 || h.y < 0 || h.x + h.w > (int)W || h.y + h.h > (int)H) return 0;
            break;
        }
        if (!found) return 0;
    }
    return 1;
}
static int app_hits_fit(void) {
    for (int i = 0; i <= app_count(); i++) {
        int found = 0;
        for (int j = 0; j < nhits; j++) if (hits[j].id == 1700 + i) {
            Hit h = hits[j]; found = 1;
            if (h.x < 0 || h.y < 0 || h.x + h.w > (int)W || h.y + h.h > (int)H) return 0;
            break;
        }
        if (!found) return 0;
    }
    return 1;
}
int main(void) {
    desk_icons = 1;   /* icons are hidden by default now; the layout checks below need them */
    mem_kb = 4u * 1024u * 1024u; /* normal-memory test baseline */
    W = 1366; H = 768; PITCH = W * 4; kernel_init();
    { /* disk command must be safe with no hardware present */
      exec_line("net"); exec_line("net up"); exec_line("ping example.com"); exec_line("dns example.com"); exec_line("http http://example.com/"); exec_line("get http://example.com/ /x"); exec_line("browser http://example.com/"); exec_line("browser https://example.com/"); exec_line("http https://example.com/"); if (net_nic.up || net_cfg) return 13; app_on = 0;
      /* Network app: boot auto-connect is harmless without a card; Connect click -> deferred job -> clear message */
      net_ui_tick(); if (!nt_boot_done) return 14;
      app_open_net(); task_sync(); compose(2000); if (app_on != NT_APP) return 15;
      nt_click(9100); if (nt_job != 1) return 16; compose(2100); if (!nt_armed) return 17; net_ui_tick(); if (nt_job || !strstr(nt_msg, "No network card")) return 18;
      nt_click(9102); if (nt_job) return 19; /* test button only works while connected */ nt_click(9104); if (nt_auto) return 20; nt_click(9104);
      if (nt_status() != 0) return 21; app_on = 0; task_sync();
      exec_line("disk list"); exec_line("disk mount 0 1"); exec_line("disk ls"); exec_line("disk format 0 1 ERASE-0-1"); exec_line("disk reset ERASE"); exec_line("disk"); if (vol.mounted || ata_n) return 11; } compose(1000);
    if (theme_i != 10 || blur_r != 8 || win_alpha != 214 || low_ram_mode || frame_interval_ms != 16) return 10;
    apply_memory_profile(2u * 1024u * 1024u);
    if (!low_ram_mode || blur_r != 2 || win_alpha != 174 || frame_interval_ms != 33 || flat_ui) return 70;
    apply_memory_profile(4u * 1024u * 1024u);
    if (low_ram_mode || blur_r != 8 || win_alpha != 214 || frame_interval_ms != 16) return 71;
    if (KEY_SPOTLIGHT != 0x111) return 11;
    if (launchpad_open || terminal_visible || app_on) return 12; /* first boot is a clean desktop */
    if (!home_node || !desktop_node || !documents_node || !downloads_node || !pictures_node) return 13;
    if (!desktop_hits_fit()) return 14;
    /* PixelBeeOS glass workspace is visible on the desktop: Spotlight, the complete app shelf,
       and the quick-control card are available without opening a full-screen launcher. */
    if (!hit_exists(2002) || !hit_exists(2001) || !hit_exists(2004)) return 35;
    /* The compact desktop dashboard intentionally replaces the former app shelf. */
    if (!hit_exists(2004)) return 37;
    /* A visible desktop shortcut launches the actual application window. */
    ui_click(1704); task_sync(); if (app_on != 4 || win_find(4) < 0) return 38;
    win_close(4); compose(1050);
    ui_click(2002); if (!launcher_open) return 39; launcher_open = 0;
    launchpad_open = 1; compose(1060); if (!app_hits_fit()) return 40; launchpad_open = 0; compose(1070);

    /* Desktop right-click menu, folder creation, Gallery and wallpaper personalization. */
    desk_menu_open = 1; desk_menu_x = 200; desk_menu_y = 160; compose(1080);
    if (!hit_exists(2200) || !hit_exists(2201) || !hit_exists(2202)) return 43;
    ui_click(2200); if (!folder_prompt) return 44;
    { const char *nm = "TestFolder"; for (int z = 0; nm[z]; z++) handle_key(nm[z]); handle_key('\n'); }
    if (folder_prompt || fs_find(desktop_node, "TestFolder") < 0) return 45;
    compose(1090); if (!hit_exists(3100 + fs_find(desktop_node, "TestFolder"))) return 46;
    /* File Manager ribbon creates a named folder inside the currently open directory. */
    app_open_files(); fa_dir = documents_node; compose(1095);
    if (!hit_exists(793)) return 64;
    ui_click(793); if (!folder_prompt || folder_parent != documents_node) return 65;
    { const char *nm = "DocsFolder"; for (int z = 0; nm[z]; z++) handle_key(nm[z]); handle_key('\n'); }
    int docs_folder = fs_find(documents_node, "DocsFolder"); if (docs_folder < 0 || !nd[docs_folder].isdir) return 66;
    /* Launchpad indexes files and folders and opens the selected result. */
    launchpad_open = 1; scpy(launchpad_query, "DocsFolder", sizeof launchpad_query); launchpad_len = 10; compose(1096);
    if (!hit_exists(2300 + docs_folder)) return 67;
    ui_click(2300 + docs_folder); if (launchpad_open || app_on != 7 || fa_dir != docs_folder) return 68;
    launchpad_open = 1; scpy(launchpad_query, "Welcome", sizeof launchpad_query); launchpad_len = 7; compose(1097);
    int welcome_node = fs_find(home_node, "Welcome.txt"); if (welcome_node < 0 || !hit_exists(2300 + welcome_node)) return 69;
    launchpad_open = 0; launchpad_query[0] = 0; launchpad_len = 0; app_on = 0;
    ui_click(2201); if (!gallery_open) return 47; handle_key(27); if (gallery_open) return 48;
    ui_click(2202); if (app_on != 9) return 49; app_on = 0;

    /* This PC opens a File Manager overview showing user folders and the C: RAM disk. */
    ui_click(3000); if (app_on != 7 || !fa_pc_view) return 15;
    task_sync(); compose(1100); if (!hit_exists(792)) return 16;
    for (int i = 0; i < 6; i++) if (!hit_exists(830 + i)) return 17;
    ui_click(792); if (fa_pc_view || fa_dir != 0) return 18;
    ui_click(3002); if (app_on != 7 || fa_dir != documents_node || fa_pc_view) return 19;

    /* Desktop and app controls remain available. */
    ui_click(2001); if (!launchpad_open) return 20;
    ui_click(2001); if (launchpad_open) return 21;
    ui_click(2003); if (!control_open) return 22;
    display_level = 90; ui_click(2101); if (display_level != 100) return 23;
    { int was = alerts_enabled; ui_click(2102); if (alerts_enabled == was) return 24; }
    handle_key(KEY_SPOTLIGHT); if (!launcher_open) return 25; launcher_open = 0;

    /* Launching Terminal from its Dock icon reveals its panel on demand. */
    ui_click(2); if (!terminal_visible) return 26;
    ui_click(2000); if (terminal_visible || !term_focus) return 27;

    app_at(6)->open(); task_sync(); if (win_find(7) < 0) return 28;
    ui_click(1400 + 7); if (win_find(7) < 0 || !win_[win_find(7)].max) return 29;
    ui_click(1300 + 7); if (win_find(7) < 0 || !win_[win_find(7)].min) return 30;
    ui_click(1000 + 7); if (win_find(7) >= 0) return 31;

    W = 1024; H = 600; PITCH = W * 4; nwin = 0; app_on = 0; terminal_visible = 0; build_scene(); compose(2000);
    if (!desktop_hits_fit()) return 32;
    launchpad_open = 1; compose(2100); if (!app_hits_fit()) return 41; launchpad_open = 0;
    W = 640; H = 480; PITCH = W * 4; nwin = 0; app_on = 0; terminal_visible = 0; build_scene(); compose(3000);
    if (!desktop_hits_fit()) return 33;
    launchpad_open = 1; compose(3100); if (!app_hits_fit()) return 42; launchpad_open = 0;
    if (dock_apps_shown >= app_count()) return 34;
    W = 1366; H = 768; PITCH = W * 4; nwin = 0; app_on = 0; terminal_visible = 0; build_scene(); compose(4000);
    if (dock_nrun != 0) return 35;                                   /* default dock: only Terminal + This PC */
    /* 2.6: Performance Center launches and performance profile is reversible. */
    app_at(10)->open(); task_sync(); if (app_on != 11 || win_find(11) < 0) return 61;
    win_close(11);
    /* 2.8: Task Manager lists live app windows and can end an app task. */
    app_at(0)->open(); task_sync(); app_at(11)->open(); task_sync(); compose(4020);
    if (app_on != 12 || win_find(12) < 0 || !hit_exists(8801)) return 64;
    tm_click(8801); if (win_find(1) >= 0) return 65;
    win_close(12);
    /* Device Manager and Security Center expose honest driver/security state. */
    app_at(12)->open(); task_sync(); compose(4030); if (app_on != 13 || win_find(13) < 0) return 66; win_close(13);
    app_at(13)->open(); task_sync(); compose(4040); if (app_on != 14 || win_find(14) < 0 || !hit_exists(8900)) return 67; win_close(14);
    app_at(8)->open(); task_sync();
    { int old = performance_mode; st_click(921); if (performance_mode == old || blur_r != 0 || !flat_ui) return 62;
      st_click(921); if (performance_mode || blur_r != 8 || flat_ui) return 63; }
    win_close(9);
    app_at(0)->open(); task_sync(); compose(4100); if (dock_nrun != 1 || dock_run[0] != 1) return 36;   /* opened app appears */
    win_close(1); compose(4200); if (dock_nrun != 0) return 37;      /* closed app disappears */
    /* --- 2.3: icons can be hidden, windows stay solid --- */
    desk_icons = 0; compose(5300); for (int i = 0; i < nhits; i++) if (hits[i].id >= 3000 && hits[i].id <= 3005) return 60;
    desk_icons = 1;
    /* --- PixelBeeOS 2.3: lock screen, snapping, Mission Control, calculator --- */
    { const char *t; int v;
      ux_passwd_start(); if (!pw_ui) return 40;
      t = "abcd\n"; for (; *t; t++) ux_key_gate(*t);                  /* new password */
      t = "abcd\n"; for (; *t; t++) ux_key_gate(*t);                  /* confirm */
      if (!pw_set || pw_ui) return 41;
      ux_lock_now(); if (!locked) return 42;
      compose(5000);                                                  /* lock screen draws */
      t = "zzzz\n"; for (; *t; t++) ux_key_gate(*t); if (!locked) return 43;  /* wrong password stays locked */
      t = "abcd\n"; for (; *t; t++) ux_key_gate(*t); if (locked) return 44;   /* right one unlocks */
      for (int f = 0; f < 3; f++) { ux_lock_now(); t = "nope\n"; for (; *t; t++) ux_key_gate(*t); }
      if (lock_until <= cur_ms) return 45;                            /* 3rd wrong try adds a delay */
      cur_ms += 1000; t = "abcd\n"; for (; *t; t++) ux_key_gate(*t); if (!locked) return 46;   /* still locked during the delay */
      cur_ms += 600000; t = "abcd\n"; for (; *t; t++) ux_key_gate(*t); if (locked) return 47;  /* unlocks after it */
      app_at(0)->open(); task_sync(); ux_snap(nwin - 1, 0); if (win_[nwin - 1].x != 0 || win_[nwin - 1].w != (int)W / 2) return 48;
      ux_snap(nwin - 1, 1); if (win_[nwin - 1].x != (int)W / 2) return 49;
      mc_open = 1; compose(5100); int found = 0; for (int i = 0; i < nhits; i++) if (hits[i].id == 4000 + nwin - 1) found = 1; if (!found) return 50;
      ux_mc_click(4000 + nwin - 1); if (mc_open) return 51;
      if (!ux_calc_query("2+3*4", &v) || v != 14) return 52; if (ux_calc_query("abc", &v) || ux_calc_query("12", &v)) return 53;
      win_close(win_[nwin - 1].app); compose(5200);
    }
    puts("PixelBeeOS 3.1 Liquid Glass low-RAM and host UI checks: PASS (desktop, multitasking windows, Task Manager termination, Device Manager, Security Center, lock screen and existing apps)");
    return 0;
}
