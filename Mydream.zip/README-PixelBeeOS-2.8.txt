PixelBeeOS 2.8 - Core OS Edition
================================

Builds on the 2.7 Clear Glass Edition. The blue desktop, bee identity, app windows,
Terminal, launcher, Control Center, RAM-backed C: file system, lock screen and
Performance Center are retained.

New in 2.8
----------
- Task Manager app (`tasks`): lists open application windows, shows Running or
  Minimized state, and can end an app window. Shell/desktop is protected.
- Device Manager app (`devices`): enumerates PCI functions and distinguishes
  detected hardware from drivers that are actually available. PS/2 input, VBE
  framebuffer and PIT clock are reported as active in this kernel.
- Security Center app (`security`): reports the current session-lock password
  state and can lock the session. `passwd` configures the lock password.
- Terminal commands: `tasks`, `meminfo`, `devices`, and `security`.
- Memory reporting separates bootloader-reported RAM from bytes stored in the
  fixed-size RAM file store. The existing file manager continues to manage the
  in-memory C: directory tree.
- PCI scan records device count and network, storage, USB and audio controller
  classes when those functions are visible on the scanned PCI buses.

Build and test
--------------
- `make` builds the 32-bit freestanding `kernel.elf`.
- `make host-test` runs interaction and regression checks, including Task Manager
  termination, Device Manager and Security Center rendering.
- `make host-preview` builds the host-side renderer used for the included UI shots.
- `make iso` creates a GRUB ISO if grub-mkrescue and xorriso are installed.
- `make run` launches the ISO in QEMU if QEMU is installed.

Important limitations (not claimed as implemented)
--------------------------------------------------
This remains an experimental hobby kernel, not a Windows/Linux replacement.
The UI event loop is cooperative: open app windows are tracked and can be closed,
but there is not yet a preemptive scheduler, independent user-process execution,
or per-process CPU-time accounting. There is no paging/virtual-memory manager or
general-purpose heap allocator; most kernel memory is statically reserved.
The C: file system is volatile RAM storage and is lost at power-off; physical
disk/SSD persistence and a journaled on-disk file system are not implemented.
Device detection does not supply drivers. PS/2 keyboard/mouse, VBE framebuffer and
PIT timing are present; USB, Wi-Fi, Bluetooth, storage, modern GPU and full audio
drivers are not implemented. User accounts and per-file ACLs are not implemented.
The screen-lock password protects the local session only; it is not multi-user
isolation. A network stack/firewall is not implemented, so the Security Center
reports firewall protection as unavailable.

A successful compile and host-side UI tests do not prove boot on every PC. Test
in QEMU first and keep backups before experimenting on physical hardware.
