#define HOSTTEST 1
#include "kernel.c"
#include <stdio.h>
#include <stdlib.h>

static int write_ppm(const char *path, int width, int height) {
    FILE *f = fopen(path, "wb");
    if (!f) return 1;
    fprintf(f, "P6\n%d %d\n255\n", width, height);
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            u32 c = back[y * W + x];
            fputc((c >> 16) & 255, f); fputc((c >> 8) & 255, f); fputc(c & 255, f);
        }
    }
    fclose(f); return 0;
}
int main(int argc, char **argv) {
    int width = 1366, height = 768;
    const char *out = "PixelBeeOS-1.1-preview.ppm";
    if (argc > 1) width = atoi(argv[1]);
    if (argc > 2) height = atoi(argv[2]);
    if (argc > 3) out = argv[3];
    if (width < 480 || height < 400 || width > MAXW || height > MAXH) return 2;
    W = (u32)width; H = (u32)height; PITCH = W * 4;
    mx = pmx = width / 2; my = pmy = height / 2;
    kernel_init();
    isl_expand = 0; timer_on = 0; /* render the settled desktop preview */
    if (argc > 4) {
        if (argv[4][0] == 't') { desktop_open_this_pc(); task_sync(); }
        else if (argv[4][0] == 'c') control_open = 1;
        else if (argv[4][0] == 'l') { launchpad_open = 1; scpy(launchpad_query, "Welcome", sizeof launchpad_query); launchpad_len = 7; }
        else if (argv[4][0] == 'p') { launchpad_open = 1; }
        else if (argv[4][0] == 'f') { app_open_files(); task_sync(); fa_dir = documents_node; folder_parent = documents_node; folder_prompt = 1; scpy(new_folder_name, "Project Notes", sizeof new_folder_name); new_folder_len = 13; }
        else if (argv[4][0] == 's') { launcher_open = 1; scpy(launcher_query, "notes", sizeof launcher_query); launcher_len = 5; }
        else if (argv[4][0] == 'm') { desk_menu_open = 1; desk_menu_x = width / 2; desk_menu_y = height / 3; }
        else if (argv[4][0] == 'k') { ux_passwd_start(); for (const char *t = "abcd\n"; *t; t++) ux_key_gate(*t); for (const char *t = "abcd\n"; *t; t++) ux_key_gate(*t); ux_lock_now(); for (const char *t = "ab"; *t; t++) ux_key_gate(*t); }
        else if (argv[4][0] == 'u') { app_at(1)->open(); task_sync(); app_at(3)->open(); task_sync(); app_at(7)->open(); task_sync(); mc_open = 1; }
        else if (argv[4][0] == 'w') { app_at(1)->open(); task_sync(); ux_snap(nwin - 1, 0); app_at(7)->open(); task_sync(); ux_snap(nwin - 1, 3); app_at(4)->open(); task_sync(); ux_snap(nwin - 1, 5); }
        else if (argv[4][0] == 'q') { launcher_open = 1; for (const char *t = "(12+8)*5"; *t; t++) { launcher_query[launcher_len++] = *t; } launcher_query[launcher_len] = 0; }
        else if (argv[4][0] == 'x') { focus_terminal(); t_say(" PixelBeeOS Terminal  -  dark glass", A_ACC); }
        else if (argv[4][0] == 'a') { for (char *p = argv[4] + 1; *p; ) { app_at(atoi(p))->open(); task_sync(); while (*p && *p != ',') p++; if (*p == ',') p++; } }
        else if (argv[4][0] == 'E') { app_at(5)->open(); task_sync(); const char *t = "# PixelBeeOS demo script\nset NAME PixelBee\necho Hello from %NAME%\nlist | grep Home | wc\nfor n in 1..3 do echo line %n%\nif exists Welcome.txt echo found it\n"; nb_len = 0; for (const char *p = t; *p; p++) nb_[nb_len++] = *p; nb_pos = 60; }
        else if (argv[4][0] == 'H') { for (int i = 0; i < 8; i++) { app_at(i)->open(); task_sync(); } for (int i = 0; i < nwin; i++) win_[i].min = 1; mouse_seen = 1; mx = atoi(argv[5]); my = (int)H - 45; }
        else if (argv[4][0] == 'B') { kbd_alive = mouse_alive = input_seen = 0; }
        else if (argv[4][0] == 'g') { gallery_open = 1; }
        else if (argv[4][0] == 'N') { memcpy(net_nic.name, "Intel e1000", 12); net_nic.up = 1; static const u8 m[6] = {0x52, 0x54, 0, 0x12, 0x34, 0x56}; memcpy(net_nic.mac, m, 6); net_cfg = 1; u8 ip[4] = {10, 0, 2, 15}, gw[4] = {10, 0, 2, 2}, dn[4] = {10, 0, 2, 3}; memcpy(net_ip, ip, 4); memcpy(net_gw, gw, 4); memcpy(net_dns, dn, 4); net_stat_rx = 412; net_stat_tx = 389;
            nt_test.ran = 1; nt_test.ping_ok = nt_test.dns_ok = nt_test.web_ok = 1; nt_test.ping_ms = 3; scpy(nt_test.dns_ip, "93.184.216.34", 20); nt_test.web_status = 200; nt_say("Internet works.", A_OK); app_open_net(); task_sync(); }
        else if (argv[4][0] == 'B') { nt_say("No network card found. In your VM choose Intel PRO/1000 (e1000), NAT.", A_ERR); app_open_net(); task_sync(); }
        else if (argv[4][0] == 'n') { folder_prompt = 1; scpy(new_folder_name, "My Folder", sizeof new_folder_name); new_folder_len = 9; }
    }
    if (argc > 5 && (argv[4][0] == 'O' || argv[4][0] == 'M' || argv[4][0] == 'L' || argv[4][0] == 'C')) {   /* animation snapshots: argv[5] = ms into the animation */
        u32 age = (u32)atoi(argv[5]); char m = argv[4][0];
        if (m == 'O') { cur_ms = 5000; app_at(1)->open(); task_sync(); app_at(3)->open(); task_sync(); cur_ms = 5000 + age; compose(5000 + age); }
        else if (m == 'M' || m == 'C') { cur_ms = 1000; app_at(1)->open(); task_sync(); app_at(3)->open(); task_sync(); cur_ms = 6000; compose(6000); if (m == 'M') win_minimize(4); else win_close(4); cur_ms = 6000 + age; compose(6000 + age); }
        else { cur_ms = 5000; launchpad_open = 1; compose(5000); cur_ms = 5000 + age; compose(5000 + age); }
        return write_ppm(out, width, height);
    }
    compose(1000); cur_ms = 3000; compose(3000);   /* second frame: animations have settled */
    return write_ppm(out, width, height);
}
